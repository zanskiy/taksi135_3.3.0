/* Такси 135 — публичный виджет [taxi135_public] v3.1.0 */
(function () {
    'use strict';
    if (typeof window.TAXI135PUB === 'undefined') return;
    var CFG = window.TAXI135PUB;

    function esc(s) {
        if (s === null || s === undefined) return '';
        return String(s).replace(/[&<>"']/g, function (c) {
            return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
        });
    }

    function apiPost(relPath, body) {
        var url = CFG.restUrl.replace(/\/$/, '') + '/' + relPath.replace(/^\//, '');
        return fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
            body: JSON.stringify(body)
        }).then(function (r) {
            return r.json().then(function (j) {
                if (!r.ok) { var e = new Error(j && j.message ? j.message : ('HTTP ' + r.status)); e.data = j; throw e; }
                return j;
            });
        });
    }

    function apiGet(relPath) {
        var url = CFG.restUrl.replace(/\/$/, '') + '/' + relPath.replace(/^\//, '');
        return fetch(url, { headers: { 'Accept': 'application/json' } }).then(function (r) {
            return r.json().then(function (j) {
                if (!r.ok) throw new Error(j && j.message ? j.message : ('HTTP ' + r.status));
                return j;
            });
        });
    }

    var map = null;
    var crewMarkers = {};

    function initMap() {
        var mapEl = document.getElementById('t135pub-map');
        if (!mapEl || typeof L === 'undefined') return;

        map = L.map('t135pub-map').setView([CFG.mapLat || 53.9, CFG.mapLng || 27.5667], CFG.mapZoom || 13);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
            maxZoom: 19
        }).addTo(map);

        var taxiIcon = L.divIcon({
            className: '',
            html: '<div style="font-size:28px;line-height:1;filter:drop-shadow(0 2px 3px rgba(0,0,0,.4));">&#x1F695;</div>',
            iconSize: [36, 36],
            iconAnchor: [18, 18]
        });

        function loadCoords() {
            apiGet('crews-coords').then(function (res) {
                var items = res.items || [];
                var seen = {};
                items.forEach(function (c) {
                    var lat = parseFloat(c.latitude  || c.lat || 0);
                    var lng = parseFloat(c.longitude || c.lon || c.lng || 0);
                    var id  = String(c.crew_id || c.id || '');
                    if (!lat || !lng || !id) return;
                    seen[id] = true;
                    var name  = esc(c.crew_name || c.name || ('Экипаж ' + id));
                    var state = esc(c.state_name || c.status || '');
                    var popup = '<strong>' + name + '</strong>' + (state ? '<br><em>' + state + '</em>' : '');
                    if (crewMarkers[id]) {
                        crewMarkers[id].setLatLng([lat, lng]).setPopupContent(popup);
                    } else {
                        crewMarkers[id] = L.marker([lat, lng], { icon: taxiIcon })
                            .bindPopup(popup).addTo(map);
                    }
                });
                Object.keys(crewMarkers).forEach(function (id) {
                    if (!seen[id]) { map.removeLayer(crewMarkers[id]); delete crewMarkers[id]; }
                });
            }).catch(function () {});
        }

        loadCoords();
        setInterval(loadCoords, 15000);
    }

    var modal     = document.getElementById('t135pub-modal');
    var form      = document.getElementById('t135pub-form');
    var openBtn   = document.getElementById('t135pub-open-order');
    var closeBtn  = document.getElementById('t135pub-close');
    var resultEl  = document.getElementById('t135pub-result');
    var submitBtn = document.getElementById('t135pub-submit');

    function openModal() {
        if (!modal) return;
        modal.hidden = false;
        document.body.style.overflow = 'hidden';
        var first = form && form.querySelector('input');
        if (first) setTimeout(function () { first.focus(); }, 60);
        if (resultEl) { resultEl.hidden = true; resultEl.className = 't135pub-result'; }
    }
    function closeModal() {
        if (!modal) return;
        modal.hidden = true;
        document.body.style.overflow = '';
    }
    function showResult(msg, ok) {
        if (!resultEl) return;
        resultEl.textContent = msg;
        resultEl.className = 't135pub-result ' + (ok ? 't135pub-result-ok' : 't135pub-result-err');
        resultEl.hidden = false;
    }
    function setLoading(on) {
        if (!submitBtn) return;
        submitBtn.disabled = on;
        submitBtn.textContent = on ? 'Отправляем заказ…' : 'Заказать такси';
    }

    if (openBtn) openBtn.addEventListener('click', openModal);
    if (closeBtn) closeBtn.addEventListener('click', closeModal);
    if (modal) {
        modal.addEventListener('click', function (e) { if (e.target === modal) closeModal(); });
        document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !modal.hidden) closeModal(); });
    }

    var phoneEl = document.getElementById('t135pub-phone');
    if (phoneEl) {
        phoneEl.addEventListener('blur', function () {
            var v = phoneEl.value.replace(/[^\d+]/g, '');
            if (v && v.length >= 10 && v[0] !== '+') v = '+' + v;
            phoneEl.value = v;
        });
    }

    if (form) {
        form.addEventListener('submit', function (e) {
            e.preventDefault();
            if (resultEl) { resultEl.hidden = true; resultEl.className = 't135pub-result'; }

            var phone  = String((form.elements['phone']       || {}).value || '').trim();
            var source = String((form.elements['source']      || {}).value || '').trim();
            var dest   = String((form.elements['destination'] || {}).value || '').trim();
            var cust   = String((form.elements['customer']    || {}).value || '').trim();
            var comm   = String((form.elements['comment']     || {}).value || '').trim();

            if (!phone)  { showResult('Укажите номер телефона.', false); if (form.elements['phone'])  form.elements['phone'].focus();  return; }
            if (!source) { showResult('Укажите адрес подачи.',   false); if (form.elements['source']) form.elements['source'].focus(); return; }

            var body = { phone: phone, source: source };
            if (dest) body.destination = dest;
            if (cust) body.customer    = cust;
            if (comm) body.comment     = comm;

            setLoading(true);
            apiPost('order', body)
                .then(function () {
                    setLoading(false);
                    showResult('Заказ принят! Диспетчер свяжется с вами в ближайшее время.', true);
                    form.reset();
                    setTimeout(closeModal, 4500);
                })
                .catch(function (err) {
                    setLoading(false);
                    showResult(err.message || 'Ошибка отправки. Попробуйте позвонить нам напрямую.', false);
                });
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initMap);
    } else {
        initMap();
    }
})();
