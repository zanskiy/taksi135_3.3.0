/* Такси 135 — dispatcher v3.3.0
 * ИСПРАВЛЕНО:
 * — Навигация: вместо атрибута hidden используется CSS-класс t135-page-hidden
 *   (атрибут hidden может сбрасываться темой WordPress через CSS display:block)
 * — Навигация: querySelectorAll ограничен контейнером #t135-app, а не всем document
 *   (исключает конфликт с другими data-nav элементами темы)
 * — Публичный шорткод инициализируется (добавлен Taxi135_Public_Shortcode::init() в PHP)
 * — href="javascript:void(0)" вместо href="#" (исключает scroll-to-top поведение тем)
 */
(function () {
    'use strict';
    if (typeof window.TAXI135 === 'undefined') return;
    var CFG = window.TAXI135;

    var app = document.getElementById('t135-app');
    if (!app) return;

    /* ─── Helpers ─── */
    function esc(s) {
        if (s === null || s === undefined) return '';
        return String(s).replace(/[&<>"']/g, function (c) {
            return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
        });
    }
    function pad(n) { return n < 10 ? '0' + n : '' + n; }
    function toTm(d) {
        return d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate()) +
            pad(d.getHours()) + pad(d.getMinutes()) + pad(d.getSeconds());
    }
    function fromTm(s) {
        if (!s || s.length < 14) return null;
        var dt = new Date(+s.slice(0, 4), +s.slice(4, 6) - 1, +s.slice(6, 8),
            +s.slice(8, 10), +s.slice(10, 12), +s.slice(12, 14));
        return isNaN(dt.getTime()) ? null : dt;
    }
    function fmtTm(s) {
        var d = fromTm(s);
        if (!d) return s || '';
        var mo = ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
        return d.getDate() + ' ' + mo[d.getMonth()] + ', ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
    }
    function inputDtVal(d) {
        return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) +
            'T' + pad(d.getHours()) + ':' + pad(d.getMinutes());
    }
    function fmtMoney(v) {
        var n = parseFloat(v) || 0;
        return n.toLocaleString('ru-RU', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' руб.';
    }
    function stars(rating) {
        if (rating === null || rating === undefined || rating === '') return '<span style="color:var(--t-muted);">—</span>';
        var r = parseFloat(rating);
        var full = Math.floor(r);
        var half = (r - full) >= 0.5 ? 1 : 0;
        var empty = 5 - full - half;
        return '<span class="t135-stars">' + '★'.repeat(full) + (half ? '½' : '') + '☆'.repeat(empty) + '</span>' +
            '<span class="t135-rating-num"> ' + r.toFixed(1) + '</span>';
    }

    /* ─── API ─── */
    function api(path, opts) {
        opts = opts || {};
        var url = CFG.restUrl.replace(/\/$/, '') + '/' + path.replace(/^\//, '');
        var headers = { 'X-WP-Nonce': CFG.nonce, 'Accept': 'application/json' };
        if (opts.headers) { Object.keys(opts.headers).forEach(function (k) { headers[k] = opts.headers[k]; }); }
        var init = { method: opts.method || 'GET', headers: headers, credentials: 'same-origin' };
        if (opts.body) { headers['Content-Type'] = 'application/json'; init.body = JSON.stringify(opts.body); }
        return fetch(url, init).then(function (r) {
            return r.json().then(function (j) {
                if (!r.ok) { var e = new Error(j && j.message ? j.message : 'HTTP ' + r.status); e.payload = j; throw e; }
                return j;
            });
        });
    }

    /* ─── Toast ─── */
    function toast(msg, kind) {
        var t = app.querySelector('#t135-toast');
        if (!t) return;
        t.className = 't135-toast ' + (kind || '');
        t.textContent = msg;
        t.style.display = 'block';
        clearTimeout(t._tmr);
        t._tmr = setTimeout(function () { t.style.display = 'none'; }, 3500);
    }
    function setError(msg) {
        var b = app.querySelector('#t135-error-banner');
        if (!b) return;
        if (msg) { b.textContent = msg; b.style.display = 'inline-block'; } else { b.style.display = 'none'; b.textContent = ''; }
    }

    /* ─── Modal ─── */
    function openModal(title, bodyHtml, onSubmit, submitLabel) {
        closeModal();
        var overlay = document.createElement('div');
        overlay.className = 't135-modal-overlay';
        overlay.id = 't135-modal-overlay';
        overlay.innerHTML =
            '<div class="t135-modal">' +
            '<div class="t135-modal-header">' +
            '<h3>' + esc(title) + '</h3>' +
            '<button class="t135-modal-close" type="button">&times;</button>' +
            '</div>' +
            '<form id="t135-modal-form">' + bodyHtml +
            (onSubmit ? '<div class="t135-form-actions" style="margin-top:16px;">' +
                '<button type="submit" class="t135-btn t135-btn-primary">' + esc(submitLabel || 'Сохранить') + '</button>' +
                '<button type="button" class="t135-btn t135-btn-ghost t135-modal-cancel">Отмена</button>' +
                '</div>' : '') +
            '</form>' +
            '</div>';
        document.body.appendChild(overlay);
        overlay.querySelector('.t135-modal-close').addEventListener('click', closeModal);
        var c = overlay.querySelector('.t135-modal-cancel');
        if (c) c.addEventListener('click', closeModal);
        overlay.addEventListener('click', function (e) { if (e.target === overlay) closeModal(); });
        if (onSubmit) {
            overlay.querySelector('#t135-modal-form').addEventListener('submit', function (e) {
                e.preventDefault();
                onSubmit(e.target);
            });
        }
        document.addEventListener('keydown', handleEsc);
    }
    function handleEsc(e) { if (e.key === 'Escape') closeModal(); }
    function closeModal() {
        var o = document.getElementById('t135-modal-overlay');
        if (o) o.remove();
        document.removeEventListener('keydown', handleEsc);
    }

    /* ─── Caches ─── */
    var Lookups = {
        crewStates: null, orderStates: null, crewGroups: null, crews: null, drivers: null,
        loadDrivers: function () {
            return api('drivers').then(function (r) { Lookups.drivers = r.items || []; return Lookups.drivers; });
        },
        loadCrews: function () {
            return api('crews').then(function (r) { Lookups.crews = r.items || []; return Lookups.crews; });
        },
        byId: function (arr, key) {
            var m = {};
            if (!arr) return m;
            for (var i = 0; i < arr.length; i++) m[arr[i][key]] = arr[i];
            return m;
        }
    };

    /* ─── Navigation ─── */
    var ALL_PAGES = ['dashboard', 'orders', 'finished', 'new-order', 'reports', 'crews', 'map', 'drivers', 'ratings'];
    var PAGE_TITLES = {
        dashboard: 'Дашборд', orders: 'Текущие заказы', finished: 'Выполненные заказы',
        'new-order': 'Создать заказ', reports: 'Отчёты',
        crews: 'Экипажи', map: 'Карта экипажей', drivers: 'Водители',
        ratings: 'Рейтинги водителей'
    };

    var refreshTimers = [];
    function clearTimers() { refreshTimers.forEach(clearInterval); refreshTimers = []; }
    function setRefresh(fn, ms) { refreshTimers.push(setInterval(fn, ms)); }

    function closeSidebar() {
        var sb = app.querySelector('#t135-sidebar');
        var ov = app.querySelector('#t135-sidebar-overlay');
        if (sb) sb.classList.remove('is-open');
        if (ov) ov.classList.remove('is-visible');
    }

    /*
     * ИСПРАВЛЕНИЕ НАВИГАЦИИ:
     * Используем CSS-класс t135-page-hidden для скрытия страниц.
     * Атрибут hidden ненадёжен — темы WordPress могут добавлять CSS
     * "[hidden] { display: block !important; }" или аналогичные переопределения.
     * Используем app.querySelectorAll вместо document.querySelectorAll
     * чтобы не захватить data-nav элементы из WordPress-темы.
     */
    function showPage(name) {
        if (!name || ALL_PAGES.indexOf(name) === -1) return;

        clearTimers();
        closeModal();
        setError('');
        closeSidebar();

        /* Скрыть ВСЕ страницы через CSS-класс */
        ALL_PAGES.forEach(function (p) {
            var node = app.querySelector('#t135-page-' + p);
            if (!node) return;
            node.classList.add('t135-page-hidden');
            node.innerHTML = '';
        });

        /* Показать нужную страницу */
        var target = app.querySelector('#t135-page-' + name);
        if (target) {
            target.classList.remove('t135-page-hidden');
            target.innerHTML = '<div class="t135-loading">Загрузка…</div>';
        }

        /* Обновить заголовок */
        var title = PAGE_TITLES[name] || name;
        var te = app.querySelector('#t135-page-title');
        if (te) te.textContent = title;
        var mt = app.querySelector('#t135-mobile-page-title');
        if (mt) mt.textContent = title;

        /* Обновить активный пункт меню — только внутри нашего контейнера */
        app.querySelectorAll('[data-nav]').forEach(function (a) {
            a.classList.toggle('is-active', a.getAttribute('data-nav') === name);
        });

        /* Запустить логику страницы */
        var fn = Pages[name];
        if (typeof fn === 'function') fn();
    }

    /* ─── Page helpers ─── */
    function kpi(title, value, sub, cls, accent) {
        return '<div class="t135-card' + (accent ? ' accent-' + accent : '') + '">' +
            '<p class="t135-card-title" style="color:#ffffff!important;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.8px;margin:0 0 10px;">' + esc(title) + '</p>' +
            '<div class="t135-kpi-value ' + (cls || '') + '">' + esc(String(value)) + '</div>' +
            (sub ? '<div class="t135-kpi-sub" style="color:#6b7fa3!important;">' + esc(sub) + '</div>' : '') +
            '</div>';
    }
    function block(title, body, accent) {
        return '<div class="t135-card' + (accent ? ' accent-' + accent : '') + '">' +
            '<p class="t135-card-title" style="color:#ffffff!important;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.8px;margin:0 0 10px;">' + esc(title) + '</p>' + body + '</div>';
    }
    function listRows(rows) {
        if (!rows || !rows.length) return '<div class="t135-empty" style="padding:12px;">Нет данных</div>';
        return '<div>' + rows.map(function (r) {
            return '<div style="display:flex;justify-content:space-between;align-items:center;' +
                'padding:7px 0;border-bottom:1px solid #1f2d45;gap:8px;">' +
                '<span style="color:#c8d3eb!important;">' + r[0] + '</span><span style="color:#f0f4ff!important;">' + r[1] + '</span></div>';
        }).join('') + '</div>';
    }
    function wraptable(html) { return '<div class="t135-table-wrap">' + html + '</div>'; }
    function emptyIcon(icon, msg) { return '<div class="t135-empty"><span class="t135-empty-icon">' + icon + '</span>' + esc(msg) + '</div>'; }
    function orderField(label, value) {
        return '<div><div class="lbl">' + esc(label) + '</div><div>' + esc(value || '—') + '</div></div>';
    }

    /* ─── Pages ─── */
    var Pages = {};

    /* ══ Dashboard ══ */
    Pages.dashboard = function () {
        var root = app.querySelector('#t135-page-dashboard');
        function render() {
            Promise.all([
                api('dashboard'),
                api('orders/current'),
                api('stats/today').catch(function () { return { orders_count: null, orders_sum: null, top_drivers: [] }; })
            ]).then(function (res) {
                var d = res[0], orders = res[1].items || [], today = res[2];
                root.innerHTML =
                    '<div class="t135-kpis">' +
                    kpi('Всего экипажей', d.total_crews || 0, (d.online_crews || 0) + ' онлайн', '', 'blue') +
                    kpi('Свободны', d.free_crews || 0, '', 'green', 'green') +
                    kpi('На заказе', d.on_order_crews || 0, '', 'yellow', 'yellow') +
                    kpi('Активные заказы', orders.length, '', 'blue', 'cyan') +
                    (today.orders_count !== null ? kpi('Заказов сегодня', today.orders_count, today.date || '', 'purple', 'purple') : '') +
                    (today.orders_sum !== null ? kpi('Выручка сегодня', fmtMoney(today.orders_sum), '', 'orange', 'orange') : '') +
                    '</div>' +
                    '<div class="t135-grid-2">' +
                    block('Экипажи по статусам', listRows((d.crews_by_state || []).map(function (s) {
                        return [esc(s.state_name), '<span class="t135-badge">' + s.count + '</span>'];
                    })), 'blue') +
                    block('Экипажи по группам', listRows((d.crews_by_group || []).map(function (g) {
                        return [esc(g.group_name), '<span class="t135-badge">' + g.count + '</span>'];
                    })), 'purple') +
                    '</div>' +
                    (today.top_drivers && today.top_drivers.length ?
                        '<div style="margin-top:14px;">' +
                        block('Топ водителей за сегодня', listRows(today.top_drivers.map(function (dr) {
                            return [esc(dr.name || 'ID ' + dr.driver_id),
                                '<span class="t135-badge yellow">' + fmtMoney(dr.sum) + '</span>' +
                                '<span class="t135-badge" style="margin-left:4px;">' + dr.count + ' зак.</span>'];
                        })), 'yellow') +
                        '</div>' : '');
            }).catch(function (e) {
                root.innerHTML = '<div class="t135-empty">Ошибка дашборда: ' + esc(e.message) + '</div>';
            });
        }
        render();
        setRefresh(render, 8000);
    };

    /* ══ Current orders ══ */
    Pages.orders = function () {
        var root = app.querySelector('#t135-page-orders');
        function editOrderModal(order, states) {
            var stOpts = states.map(function (s) {
                return '<option value="' + s.id + '"' + (s.id === order.state_id ? ' selected' : '') + '>' + esc(s.name) + '</option>';
            }).join('');
            openModal('Редактировать заказ #' + order.id,
                '<div class="t135-form" style="grid-template-columns:1fr 1fr;max-width:100%;">' +
                '<div class="t135-field full"><label>Откуда</label><input name="source" value="' + esc(order.source || '') + '"></div>' +
                '<div class="t135-field full"><label>Куда</label><input name="destination" value="' + esc(order.destination || '') + '"></div>' +
                '<div class="t135-field"><label>Телефон</label><input name="phone" value="' + esc(order.phone || '') + '"></div>' +
                '<div class="t135-field"><label>Клиент</label><input name="customer" value="' + esc(order.customer || order.client_name || '') + '"></div>' +
                '<div class="t135-field full"><label>Комментарий</label><textarea name="comment">' + esc(order.comment || '') + '</textarea></div>' +
                '<div class="t135-field full"><label>Статус</label><select name="state_id">' + stOpts + '</select></div>' +
                '</div>',
                function (form) {
                    var fd = new FormData(form);
                    var body = {};
                    fd.forEach(function (v, k) { body[k] = v; });
                    var newSid = +body.state_id;
                    var btn = form.querySelector('button[type=submit]');
                    btn.disabled = true;
                    btn.textContent = 'Сохранение…';
                    var tasks = [api('orders/' + order.id, { method: 'POST', body: body })];
                    if (newSid && newSid !== order.state_id)
                        tasks.push(api('orders/' + order.id + '/state', { method: 'POST', body: { state_id: newSid } }));
                    Promise.all(tasks)
                        .then(function () { toast('Заказ #' + order.id + ' обновлён', 'success'); closeModal(); render(); })
                        .catch(function (e) { toast('Ошибка: ' + e.message, 'error'); btn.disabled = false; btn.textContent = 'Сохранить'; });
                }, 'Сохранить');
        }
        function render() {
            var pOrders = api('orders/current');
            var pStates = Lookups.orderStates ? Promise.resolve({ items: Lookups.orderStates }) :
                api('order-states').then(function (r) { Lookups.orderStates = r.items; return r; });
            var pCrews = Lookups.crews ? Promise.resolve({ items: Lookups.crews }) : Lookups.loadCrews().then(function (i) { return { items: i }; });
            var pDrivers = Lookups.drivers ? Promise.resolve({ items: Lookups.drivers }) : Lookups.loadDrivers().then(function (i) { return { items: i }; });
            Promise.all([pOrders, pStates, pCrews, pDrivers]).then(function (res) {
                var ords = res[0].items || [], states = res[1].items || [];
                var cm = Lookups.byId(res[2].items, 'crew_id'), dm = Lookups.byId(res[3].items, 'driver_id');
                if (!ords.length) { root.innerHTML = emptyIcon('📋', 'Активных заказов нет'); return; }
                root.innerHTML = '<div class="t135-orders">' + ords.map(function (o) {
                    var crew = cm[o.crew_id], drv = dm[o.driver_id];
                    var stName = (states.find(function (s) { return s.id === o.state_id; }) || {}).name || ('#' + o.state_id);
                    var stKind = ('' + (o.state_kind || '')).toLowerCase();
                    var bc = stKind === 'free' ? 'green' : (stKind.indexOf('cancel') >= 0 ? 'red' : 'blue');
                    var sel = '<select class="t135-state-sel t135-btn t135-btn-sm" data-id="' + o.id + '">' +
                        states.map(function (s) { return '<option value="' + s.id + '"' + (s.id === o.state_id ? ' selected' : '') + '>' + esc(s.name) + '</option>'; }).join('') + '</select>';
                    return '<div class="t135-order">' +
                        '<div>' +
                        '<div class="t135-order-head">' +
                        '<span class="t135-order-id">#' + esc(o.id) + '</span>' +
                        '<span class="t135-badge ' + bc + '">' + esc(stName) + '</span>' +
                        (o.start_time ? '<span class="t135-mono" style="font-size:12px;">' + esc(fmtTm(o.start_time)) + '</span>' : '') +
                        '</div>' +
                        '<div class="t135-order-meta">' +
                        orderField('Откуда', o.source) + orderField('Куда', o.destination) +
                        orderField('Клиент', o.customer || o.client_name) + orderField('Телефон', o.phone) +
                        orderField('Экипаж', crew ? (crew.code + ' — ' + crew.name) : (o.crew_id ? '#' + o.crew_id : null)) +
                        orderField('Водитель', drv ? drv.name : (o.driver_id ? '#' + o.driver_id : null)) +
                        '</div>' +
                        '</div>' +
                        '<div class="t135-order-side">' +
                        '<div class="t135-card-title">Статус</div>' + sel +
                        '<button class="t135-btn t135-btn-sm" style="margin-top:6px;" data-edit="' + o.id + '">✎ Изменить</button>' +
                        '</div>' +
                        '</div>';
                }).join('') + '</div>';
                root.querySelectorAll('.t135-state-sel').forEach(function (sel) {
                    var init = sel.value;
                    sel.addEventListener('change', function () {
                        var id = sel.getAttribute('data-id');
                        sel.disabled = true;
                        api('orders/' + id + '/state', { method: 'POST', body: { state_id: +sel.value } })
                            .then(function () { toast('Статус обновлён', 'success'); render(); })
                            .catch(function (e) { toast('Ошибка: ' + e.message, 'error'); sel.value = init; })
                            .then(function () { sel.disabled = false; });
                    });
                });
                root.querySelectorAll('[data-edit]').forEach(function (btn) {
                    btn.addEventListener('click', function () {
                        var id = +btn.getAttribute('data-edit');
                        var o = (res[0].items || []).find(function (x) { return x.id === id; });
                        if (o) editOrderModal(o, states);
                    });
                });
            }).catch(function (e) { root.innerHTML = '<div class="t135-empty">Ошибка: ' + esc(e.message) + '</div>'; });
        }
        render();
        setRefresh(render, 6000);
    };

    /* ══ Finished orders ══ */
    Pages.finished = function () {
        var root = app.querySelector('#t135-page-finished');
        var now = new Date(), dayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0);

        /* Вычисление стоимости: PHP инжектирует _cost, JS читает его как приоритет */
        function _getCost(o) {
            if (o._cost !== undefined && o._cost > 0) return parseFloat(o._cost);
            var _cf = ['sum','total_sum','cost','order_sum','total','price','amount','fare','cost_client','client_cost','cash_sum'];
            for (var _i = 0; _i < _cf.length; _i++) { var _v = parseFloat(o[_cf[_i]]); if (_v > 0) return _v; }
            return 0;
        }

        root.innerHTML =
            '<div class="t135-toolbar">' +
            '<div class="t135-toolbar-row">' +
            '<div class="t135-field"><label>С</label>' +
            '<input type="datetime-local" id="t135-fin-start" value="' + inputDtVal(dayStart) + '"></div>' +
            '<div class="t135-field"><label>По</label>' +
            '<input type="datetime-local" id="t135-fin-end" value="' + inputDtVal(now) + '"></div>' +
            '<div class="t135-field"><label>Водитель</label>' +
            '<select id="t135-fin-drv"><option value="">Все водители</option></select></div>' +
            '<button class="t135-btn t135-btn-primary" id="t135-fin-load">Показать</button>' +
            '</div>' +
            '<button class="t135-btn" id="t135-fin-csv" disabled>⬇ CSV</button>' +
            '</div>' +
            '<div id="t135-fin-stats" class="t135-stats-row"></div>' +
            '<div id="t135-fin-result"></div>';

        var out = root.querySelector('#t135-fin-result');
        var statsEl = root.querySelector('#t135-fin-stats');
        var csvBtn = root.querySelector('#t135-fin-csv');
        var drvSel = root.querySelector('#t135-fin-drv');
        var lastItems = [];

        /* Заполнить дропдаун водителей */
        (Lookups.drivers ? Promise.resolve(Lookups.drivers) : Lookups.loadDrivers()).then(function (drv) {
            drv.slice().sort(function (a, b) { return (a.name || '').localeCompare(b.name || ''); })
                .forEach(function (d) {
                    var opt = document.createElement('option');
                    opt.value = d.driver_id;
                    opt.textContent = d.name || ('#' + d.driver_id);
                    drvSel.appendChild(opt);
                });
        });

        function doLoad() {
            var s = new Date(root.querySelector('#t135-fin-start').value);
            var e = new Date(root.querySelector('#t135-fin-end').value);
            if (isNaN(s.getTime()) || isNaN(e.getTime())) { toast('Неверные даты', 'error'); return; }

            out.innerHTML = '<div class="t135-loading">Загрузка…</div>';
            statsEl.innerHTML = '';
            csvBtn.disabled = true;

            var filterDrv = drvSel.value ? parseInt(drvSel.value, 10) : 0;
            var _fldsFin = 'sum,total_sum,cash_sum,cashless_sum,driver_id,driver_name,crew_id,start_time,finish_time,source,destination,state_id,client_name,phone';
            var url = 'orders/finished?start_time=' + toTm(s) + '&finish_time=' + toTm(e) +
                (filterDrv ? '&driver_id=' + filterDrv : '') +
                '&fields=' + encodeURIComponent(_fldsFin);

            var pDrivers = Lookups.drivers ? Promise.resolve(Lookups.byId(Lookups.drivers, 'driver_id')) :
                Lookups.loadDrivers().then(function (i) { return Lookups.byId(i, 'driver_id'); });
            var pCrews = Lookups.crews ? Promise.resolve(Lookups.byId(Lookups.crews, 'crew_id')) :
                Lookups.loadCrews().then(function (i) { return Lookups.byId(i, 'crew_id'); });

            Promise.all([api(url), pDrivers, pCrews]).then(function (res) {
                lastItems = res[0].items || [];
                var dm = res[1], cm = res[2];
                lastItems.forEach(function (o) {
                    if (!o.driver_name && dm[o.driver_id]) o.driver_name = dm[o.driver_id].name;
                    if (!o.crew_code && cm[o.crew_id]) o.crew_code = cm[o.crew_id].code;
                });

                /* Клиентская фильтрация (запасная) */
                var shown = filterDrv ? lastItems.filter(function (o) { return +o.driver_id === filterDrv; }) : lastItems;

                if (!shown.length) { out.innerHTML = emptyIcon('✅', 'Заказов за период не найдено'); return; }

                var total = 0;
                shown.forEach(function (o) { total += _getCost(o); });

                statsEl.innerHTML =
                    '<div class="t135-stat-pill blue">Заказов: <strong>' + shown.length + '</strong></div>' +
                    '<div class="t135-stat-pill green">Сумма: <strong>' + fmtMoney(total) + '</strong></div>' +
                    (filterDrv && shown.length ? '<div class="t135-stat-pill">Ср. заказ: <strong>' + fmtMoney(total / shown.length) + '</strong></div>' : '');

                csvBtn.disabled = false;

                var rows = shown.map(function (o) {
                    var cost = _getCost(o);
                    var phone = o.phone || o.client_phone || '';
                    return '<tr>' +
                        '<td class="t135-mono">' + esc(o.id) + '</td>' +
                        '<td style="white-space:nowrap;">' + esc(fmtTm(o.start_time || o.create_time)) + '</td>' +
                        '<td>' + esc(o.source || '—') + '</td>' +
                        '<td>' + esc(o.destination || '—') + '</td>' +
                        '<td>' + esc(o.driver_name || (o.driver_id ? '#' + o.driver_id : '—')) + '</td>' +
                        '<td class="t135-mono">' + esc(o.crew_code || (o.crew_id ? '#' + o.crew_id : '—')) + '</td>' +
                        (phone ? '<td class="t135-mono">' + esc(phone) + '</td>' : '<td>—</td>') +
                        '<td class="t135-balance-pos" style="text-align:right;white-space:nowrap;">' + fmtMoney(cost) + '</td>' +
                        '</tr>';
                }).join('');

                out.innerHTML = wraptable(
                    '<table class="t135-table"><thead><tr>' +
                    '<th>ID</th><th>Время</th><th>Откуда</th><th>Куда</th><th>Водитель</th><th>Экипаж</th><th>Телефон</th><th style="text-align:right;">Сумма</th>' +
                    '</tr></thead><tbody>' + rows + '</tbody></table>'
                );
            }).catch(function (e) { out.innerHTML = '<div class="t135-empty">Ошибка: ' + esc(e.message) + '</div>'; });
        }

        root.querySelector('#t135-fin-load').addEventListener('click', doLoad);
        csvBtn.addEventListener('click', function () {
            if (!lastItems.length) return;
            var filterDrv = drvSel.value ? parseInt(drvSel.value, 10) : 0;
            var shown = filterDrv ? lastItems.filter(function (o) { return +o.driver_id === filterDrv; }) : lastItems;
            var cols = ['ID', 'Время', 'Откуда', 'Куда', 'Водитель', 'Экипаж', 'Телефон', 'Сумма'];
            var rows = shown.map(function (o) {
                return [o.id, fmtTm(o.start_time || o.create_time), o.source, o.destination,
                    o.driver_name || (o.driver_id ? '#' + o.driver_id : ''),
                    o.crew_code || (o.crew_id ? '#' + o.crew_id : ''),
                    o.phone || o.client_phone || '',
                    _getCost(o).toFixed(2)
                ].map(function (v) { return '"' + String(v || '').replace(/"/g, '""') + '"'; }).join(',');
            });
            var csv = '\uFEFF' + cols.map(function (c) { return '"' + c + '"'; }).join(',') + '\n' + rows.join('\n');
            var a = document.createElement('a');
            a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8;' }));
            a.download = 'finished_orders_' + toTm(new Date()) + '.csv';
            document.body.appendChild(a);
            a.click();
            setTimeout(function () { document.body.removeChild(a); URL.revokeObjectURL(a.href); }, 1000);
        });
        doLoad();
    };

    /* ══ New order ══ */
    Pages['new-order'] = function () {
        var root = app.querySelector('#t135-page-new-order');
        root.innerHTML =
            '<div class="t135-card" style="max-width:600px;">' +
            '<p class="t135-section-title">➕ Новый заказ</p>' +
            '<form class="t135-form" id="t135-new-order" style="grid-template-columns:1fr 1fr;">' +
            '<div class="t135-field"><label>Телефон *</label><input name="phone" required placeholder="+375..."></div>' +
            '<div class="t135-field"><label>Имя клиента</label><input name="customer"></div>' +
            '<div class="t135-field full"><label>Откуда *</label><input name="source" required placeholder="ул. Ленина, 1"></div>' +
            '<div class="t135-field full"><label>Куда</label><input name="destination"></div>' +
            '<div class="t135-field"><label>На время</label><input name="source_time" type="datetime-local"></div>' +
            '<div class="t135-field full"><label>Комментарий</label><textarea name="comment"></textarea></div>' +
            '<div class="t135-form-actions full">' +
            '<button class="t135-btn t135-btn-primary" type="submit">🚖 Создать заказ</button>' +
            '</div>' +
            '</form>' +
            '</div>';
        root.querySelector('#t135-new-order').addEventListener('submit', function (e) {
            e.preventDefault();
            var fd = new FormData(e.target), body = {};
            fd.forEach(function (v, k) { if (v) body[k] = v; });
            if (body.source_time) {
                var d = new Date(body.source_time);
                if (!isNaN(d.getTime())) body.source_time = toTm(d);
                else delete body.source_time;
            }
            var btn = e.target.querySelector('button[type=submit]');
            btn.disabled = true;
            btn.textContent = 'Создание…';
            api('orders', { method: 'POST', body: body })
                .then(function () { toast('Заказ создан', 'success'); e.target.reset(); })
                .catch(function (err) { toast('Ошибка: ' + err.message, 'error'); })
                .then(function () { btn.disabled = false; btn.textContent = '🚖 Создать заказ'; });
        });
    };

    /* ══ Reports ══ */
    Pages.reports = function () {
        var root = app.querySelector('#t135-page-reports');
        var now = new Date(), dayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0);

        root.innerHTML =
            '<div class="t135-toolbar">' +
            '<div class="t135-toolbar-row">' +
            '<div class="t135-field"><label>С</label>' +
            '<input type="datetime-local" id="t135-rep-start" value="' + inputDtVal(dayStart) + '"></div>' +
            '<div class="t135-field"><label>По</label>' +
            '<input type="datetime-local" id="t135-rep-end" value="' + inputDtVal(now) + '"></div>' +
            '<button class="t135-btn t135-btn-primary" id="t135-rep-load">Сформировать</button>' +
            '</div>' +
            '<button class="t135-btn" id="t135-rep-csv" disabled>⬇ Экспорт CSV</button>' +
            '</div>' +
            '<div id="t135-rep-result"></div>';

        var out = root.querySelector('#t135-rep-result');
        var csvBtn = root.querySelector('#t135-rep-csv');
        var lastReport = null;

        function doLoad() {
            var s = new Date(root.querySelector('#t135-rep-start').value);
            var e = new Date(root.querySelector('#t135-rep-end').value);
            if (isNaN(s.getTime()) || isNaN(e.getTime())) { toast('Неверные даты', 'error'); return; }
            out.innerHTML = '<div class="t135-loading">Формирование отчёта…</div>';
            csvBtn.disabled = true;

            var pDrivers = Lookups.drivers ? Promise.resolve(Lookups.byId(Lookups.drivers, 'driver_id')) :
                Lookups.loadDrivers().then(function (i) { return Lookups.byId(i, 'driver_id'); });
            var fields = 'sum,total_sum,cash_sum,cashless_sum,driver_id,driver_name,start_time,finish_time,source,destination,state_id,crew_id,client_name,phone';
            var url = 'orders/finished?start_time=' + toTm(s) + '&finish_time=' + toTm(e) + '&fields=' + encodeURIComponent(fields);
            Promise.all([api(url), pDrivers]).then(function (res) {
                var items = res[0].items || [], dm = res[1];
                items.forEach(function (o) { if (!o.driver_name && dm[o.driver_id]) o.driver_name = dm[o.driver_id].name; });
                if (!items.length) { out.innerHTML = emptyIcon('📈', 'Заказов за период не найдено'); return; }

                var totalOrders = items.length, totalSum = 0, driverStats = {};
                items.forEach(function (o) {
                    /* || пропускает 0 правильно в JS, но расставляем sum первым по документации TM API */
                    var _fields = ['sum', 'total_sum', 'cost', 'order_sum', 'total', 'price', 'amount', 'fare', 'cost_client', 'client_cost', 'cash_sum'];
                    var cost = 0;
                    for (var _fi = 0; _fi < _fields.length; _fi++) {
                        var _v = parseFloat(o[_fields[_fi]]);
                        if (_v > 0) { cost = _v; break; }
                    }
                    totalSum += cost;
                    var did = o.driver_id || '__unknown__';
                    var dn = o.driver_name || (dm[did] ? dm[did].name : '') || ('ID ' + did);
                    if (!driverStats[did]) driverStats[did] = { name: dn, count: 0, sum: 0, profit: 0 };
                    driverStats[did].count++;
                    driverStats[did].sum += cost;
                    driverStats[did].profit += cost * 0.2;
                });
                var companyProfit = totalSum * 0.2;
                lastReport = { items: items, driverStats: driverStats, totalSum: totalSum, totalOrders: totalOrders, companyProfit: companyProfit };
                csvBtn.disabled = false;

                var dRows = Object.values(driverStats).sort(function (a, b) { return b.sum - a.sum; });
                var maxSum = dRows.length ? dRows[0].sum : 1;
                out.innerHTML =
                    '<div class="t135-kpis" style="margin-bottom:20px;">' +
                    kpi('Всего заказов', totalOrders, '', 'blue', 'blue') +
                    kpi('Общая сумма', fmtMoney(totalSum), '', 'green', 'green') +
                    kpi('Прибыль фирмы (~20%)', fmtMoney(companyProfit), '', 'orange', 'orange') +
                    kpi('Водителей', dRows.length, '', 'purple', 'purple') +
                    '</div>' +
                    '<div class="t135-section-title" style="margin-bottom:10px;">👤 Отчёт по водителям</div>' +
                    wraptable('<table class="t135-table"><thead><tr>' +
                        '<th>#</th><th>Водитель</th><th>Заказов</th>' +
                        '<th style="text-align:right;">Заработок</th>' +
                        '<th style="text-align:right;">Прибыль фирмы</th>' +
                        '<th>Доля</th></tr></thead><tbody>' +
                        dRows.map(function (dr, i) {
                            var pct = maxSum > 0 ? Math.round(dr.sum / maxSum * 100) : 0;
                            return '<tr>' +
                                '<td class="t135-mono" style="color:var(--t-muted);">' + (i + 1) + '</td>' +
                                '<td style="font-weight:700;">' + esc(dr.name) + '</td>' +
                                '<td><span class="t135-badge blue">' + dr.count + '</span></td>' +
                                '<td class="t135-balance-pos" style="text-align:right;">' + fmtMoney(dr.sum) + '</td>' +
                                '<td class="t135-balance-pos" style="text-align:right;">' + fmtMoney(dr.profit) + '</td>' +
                                '<td style="min-width:100px;">' +
                                '<div class="t135-progress-wrap"><div class="t135-progress-bar" style="width:' + pct + '%;background:linear-gradient(90deg,#34d399,#059669);"></div></div>' +
                                '<small style="color:var(--t-muted);">' + pct + '%</small>' +
                                '</td></tr>';
                        }).join('') +
                        '</tbody></table>');
            }).catch(function (e) { out.innerHTML = '<div class="t135-empty">Ошибка: ' + esc(e.message) + '</div>'; });
        }

        root.querySelector('#t135-rep-load').addEventListener('click', doLoad);
        csvBtn.addEventListener('click', function () {
            if (!lastReport) return;
            var rows = Object.values(lastReport.driverStats).sort(function (a, b) { return b.sum - a.sum; });
            var cols = ['Водитель', 'Заказов', 'Заработок (руб.)', 'Прибыль фирмы (руб.)'];
            var data = rows.map(function (dr) {
                return [dr.name, dr.count, dr.sum.toFixed(2), dr.profit.toFixed(2)]
                    .map(function (v) { return '"' + String(v).replace(/"/g, '""') + '"'; }).join(',');
            });
            data.unshift('"Итого","' + lastReport.totalOrders + '","' + lastReport.totalSum.toFixed(2) + '","' + lastReport.companyProfit.toFixed(2) + '"');
            var csv = '\uFEFF' + cols.map(function (c) { return '"' + c + '"'; }).join(',') + '\n' + data.join('\n');
            var a = document.createElement('a');
            a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8;' }));
            a.download = 'report_' + toTm(new Date()) + '.csv';
            document.body.appendChild(a);
            a.click();
            setTimeout(function () { document.body.removeChild(a); URL.revokeObjectURL(a.href); }, 1000);
        });
        doLoad();
    };

    /* ══ Crews ══ */
    Pages.crews = function () {
        var root = app.querySelector('#t135-page-crews');
        function render() {
            var pStates = Lookups.crewStates ? Promise.resolve({ items: Lookups.crewStates }) :
                api('crew-states').then(function (r) { Lookups.crewStates = r.items; return r; });
            var pGroups = Lookups.crewGroups ? Promise.resolve({ items: Lookups.crewGroups }) :
                api('crew-groups').then(function (r) { Lookups.crewGroups = r.items; return r; });
            var pDrivers = Lookups.drivers ? Promise.resolve({ items: Lookups.drivers }) : Lookups.loadDrivers().then(function (i) { return { items: i }; });
            Promise.all([api('crews'), pStates, pGroups, pDrivers]).then(function (res) {
                Lookups.crews = res[0].items || [];
                var sm = Lookups.byId(res[1].items, 'id'), gm = Lookups.byId(res[2].items, 'id'), dm = Lookups.byId(res[3].items, 'driver_id');
                var rows = Lookups.crews.map(function (c) {
                    var st = sm[c.crew_state_id], stk = st ? ('' + st.state_type).toLowerCase() : '';
                    var bc = stk === 'free' ? 'green' : (stk === 'on_order' || stk === 'busy' ? 'yellow' : 'blue');
                    return '<tr>' +
                        '<td class="t135-mono">' + esc(c.code) + '</td>' +
                        '<td style="font-weight:600;">' + esc(c.name) + '</td>' +
                        '<td>' + esc((gm[c.crew_group_id] || {}).name || '—') + '</td>' +
                        '<td><span class="t135-badge ' + bc + '">' + esc((st || {}).name || ('#' + c.crew_state_id)) + '</span></td>' +
                        '<td>' + esc((dm[c.driver_id] || {}).name || (c.driver_id ? '#' + c.driver_id : '—')) + '</td>' +
                        '<td>' + (c.online ? '<span class="t135-badge green">онлайн</span>' : '<span class="t135-badge">офлайн</span>') + '</td>' +
                        '</tr>';
                }).join('');
                root.innerHTML = wraptable('<table class="t135-table"><thead><tr><th>Код</th><th>Название</th><th>Группа</th><th>Статус</th><th>Водитель</th><th>Сеть</th></tr></thead><tbody>' + rows + '</tbody></table>');
            }).catch(function (e) { root.innerHTML = emptyIcon('🚗', 'Ошибка: ' + e.message); });
        }
        render();
        setRefresh(render, 10000);
    };

    /* ══ Map ══ */
    Pages.map = function () {
        var root = app.querySelector('#t135-page-map');
        root.innerHTML = '<div id="t135-leaflet" class="t135-map" style="height:520px;"></div>';
        var mapEl = root.querySelector('#t135-leaflet');
        var map = L.map(mapEl).setView([52.7867, 27.5419], 12);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '© OpenStreetMap', maxZoom: 19 }).addTo(map);
        var layer = L.layerGroup().addTo(map);
        function render() {
            var pCrews = Lookups.crews ? Promise.resolve({ items: Lookups.crews }) : Lookups.loadCrews().then(function (i) { return { items: i }; });
            Promise.all([api('crews/coords'), pCrews]).then(function (res) {
                var coords = res[0].items || [], cm = Lookups.byId(res[1].items, 'crew_id');
                layer.clearLayers();
                coords.forEach(function (c) {
                    if (!c.lat || !c.lon) return;
                    var crew = cm[c.crew_id], stk = ('' + (c.state_kind || '')).toLowerCase();
                    var color = stk === 'free' ? '#34d399' : (stk === 'on_order' || stk === 'busy' ? '#fbbf24' : '#60a5fa');
                                var callsign = c.crew_code || (crew ? (crew.code || crew.name || '') : '') || ('#' + c.crew_id);
                    var icon = L.divIcon({
                        className: '',
                        html: '<div style="background:' + color + ';color:#000;width:34px;height:34px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:10px;border:2px solid rgba(255,255,255,.7);box-shadow:0 2px 6px rgba(0,0,0,.4);white-space:nowrap;overflow:hidden;">' + esc(callsign) + '</div>',
                        iconSize: [34, 34],
                        iconAnchor: [17, 17],
                        popupAnchor: [0, -17]
                    });
                    L.marker([c.lat, c.lon], { icon: icon })
                        .bindPopup('<b>' + esc(callsign) + '</b><br>' + esc(crew ? crew.name || '' : '') + '<br>' + (c.speed || 0) + ' км/ч')
                        .addTo(layer);
                });
            }).catch(function () {});
        }
        setTimeout(function () { map.invalidateSize(); render(); }, 60);
        setRefresh(render, 6000);
    };

    /* ══ Drivers ══ */
    Pages.drivers = function () {
        var root = app.querySelector('#t135-page-drivers');
        function balCls(v) { return v > 0 ? 't135-balance-pos' : v < 0 ? 't135-balance-neg' : 't135-balance-zero'; }

        function openBalModal(driver) {
            openModal('Пополнение баланса: ' + driver.name,
                '<div class="t135-form" style="grid-template-columns:1fr;max-width:100%;">' +
                '<div class="t135-field"><label>Сумма (+ пополнение, − списание)</label>' +
                '<input name="amount" type="number" step="0.01" required placeholder="100.00 или -50.00"></div>' +
                '<div class="t135-field"><label>Комментарий</label><input name="description" placeholder="Необязательно"></div>' +
                '</div>',
                function (form) {
                    var amount = parseFloat(form.querySelector('[name=amount]').value);
                    var desc = form.querySelector('[name=description]').value;
                    if (isNaN(amount)) { toast('Введите сумму', 'error'); return; }
                    var btn = form.querySelector('button[type=submit]');
                    btn.disabled = true;
                    btn.textContent = 'Сохранение…';
                    api('drivers/' + driver.driver_id + '/balance', { method: 'POST', body: { amount: amount, description: desc } })
                        .then(function () { toast('Баланс обновлён', 'success'); closeModal(); Lookups.drivers = null; Pages.drivers(); })
                        .catch(function (e) { toast('Ошибка: ' + e.message, 'error'); btn.disabled = false; btn.textContent = 'Сохранить'; });
                }, 'Сохранить');
        }

        (Lookups.drivers ? Promise.resolve({ items: Lookups.drivers }) : Lookups.loadDrivers().then(function (i) { return { items: i }; }))
            .then(function (res) {
                var drivers = res.items || [];
                if (!drivers.length) { root.innerHTML = emptyIcon('👤', 'Водителей не найдено'); return; }
                var dm = Lookups.byId(drivers, 'driver_id');
                var rows = drivers.map(function (d) {
                    var bal = parseFloat(d.balance || 0);
                    var rating = d.rating !== undefined ? d.rating : d.mark;
                    return '<tr>' +
                        '<td class="t135-mono">' + esc(d.driver_id || d.id || '') + '</td>' +
                        '<td style="font-weight:700;">' + esc(d.name || '') + '</td>' +
                        '<td class="t135-mono">' + esc(d.phone || d.mobile_phone || '—') + '</td>' +
                        '<td>' + (d.is_active ? '<span class="t135-badge green">Активен</span>' : '<span class="t135-badge">Неактивен</span>') + '</td>' +
                        '<td><span class="' + balCls(bal) + '">' + bal.toFixed(2) + ' руб.</span></td>' +
                        '<td>' + (rating !== undefined && rating !== null ? stars(rating) : '—') + '</td>' +
                        '<td><div class="t135-actions-cell">' +
                        '<button class="t135-btn t135-btn-sm t135-bal-btn" data-id="' + esc(d.driver_id) + '" title="Пополнить/списать баланс">💰 Баланс</button>' +
                        '</div></td>' +
                        '</tr>';
                }).join('');
                root.innerHTML = wraptable('<table class="t135-table"><thead><tr>' +
                    '<th>ID</th><th>Имя</th><th>Телефон</th><th>Статус</th><th>Баланс</th><th>Рейтинг</th><th>Действия</th>' +
                    '</tr></thead><tbody>' + rows + '</tbody></table>');
                root.querySelectorAll('.t135-bal-btn').forEach(function (btn) {
                    btn.addEventListener('click', function () { openBalModal(dm[btn.getAttribute('data-id')]); });
                });
            }).catch(function (e) { root.innerHTML = emptyIcon('👤', 'Ошибка: ' + e.message); });
    };

    /* ══ Ratings ══ */
    Pages.ratings = function () {
        var root = app.querySelector('#t135-page-ratings');
        api('drivers/ratings').then(function (res) {
            var items = res.items || [];
            if (!items.length) { root.innerHTML = emptyIcon('⭐', 'Рейтинги не найдены'); return; }
            items.sort(function (a, b) { return parseFloat(b.rating || b.mark || 0) - parseFloat(a.rating || a.mark || 0); });
            var rows = items.map(function (d, i) {
                var rating = d.rating !== undefined ? d.rating : d.mark;
                var trips = d.trips || d.trips_count || d.orders_count || d.finished_orders_count || d.completed_orders || d.trip_count || d.order_count || d.rides_count;
                var medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : (i + 1);
                return '<tr>' +
                    '<td style="font-size:18px;text-align:center;">' + medal + '</td>' +
                    '<td style="font-weight:700;">' + esc(d.name || '#' + d.driver_id) + '</td>' +
                    '<td>' + stars(rating) + '</td>' +
                    '<td class="t135-mono">' + (trips !== undefined && trips !== null ? trips : '—') + '</td>' +
                    '<td>' + (d.balance !== undefined && d.balance !== null ? '<span class="' + (parseFloat(d.balance || 0) >= 0 ? 't135-balance-pos' : 't135-balance-neg') + '">' + parseFloat(d.balance || 0).toFixed(2) + ' руб.</span>' : '—') + '</td>' +
                    '</tr>';
            }).join('');
            root.innerHTML = wraptable('<table class="t135-table"><thead><tr>' +
                '<th style="text-align:center;">Место</th><th>Водитель</th><th>Рейтинг</th><th>Поездок</th><th>Баланс</th>' +
                '</tr></thead><tbody>' + rows + '</tbody></table>');
        }).catch(function (e) { root.innerHTML = emptyIcon('⭐', 'Ошибка: ' + e.message); });
    };

    /* ─── Wire nav click handlers (ТОЛЬКО внутри нашего контейнера) ─── */
    app.querySelectorAll('[data-nav]').forEach(function (el) {
        el.addEventListener('click', function (e) {
            e.preventDefault();
            showPage(el.getAttribute('data-nav'));
        });
    });

    /* ─── Refresh button ─── */
    var rfBtn = app.querySelector('#t135-refresh');
    if (rfBtn) rfBtn.addEventListener('click', function () {
        var active = app.querySelector('[data-nav].is-active');
        if (active) showPage(active.getAttribute('data-nav'));
    });

    /* ─── Mobile sidebar ─── */
    var hamburger = app.querySelector('#t135-hamburger');
    var sidebar = app.querySelector('#t135-sidebar');
    var sidebarOv = app.querySelector('#t135-sidebar-overlay');
    if (hamburger) {
        hamburger.addEventListener('click', function () {
            if (sidebar) sidebar.classList.toggle('is-open');
            if (sidebarOv) sidebarOv.classList.toggle('is-visible');
        });
    }
    if (sidebarOv) sidebarOv.addEventListener('click', closeSidebar);

    /* ─── Start ─── */
    showPage('dashboard');

})();
