<?php
/**
 * REST endpoints under /wp-json/taxi135/v1/*.
 *
 * v3.2.2:
 *   — /orders/finished: правильный параметр finish_time (не end_time),
 *     поддержка фильтра по driver_id
 *   — send_driver_message: убран SMS-фоллбэк (Код 6 — метод не существует);
 *     кнопка «Сообщение» убрана из UI водителей
 *   — Вкладка «Сообщения» удалена (TaxiMaster API не раскрывает входящие TMDriver)
 *   — CSS: защита цветов от переопределения темой WordPress
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Taxi135_REST {

    public static function init() {
        add_action( 'rest_api_init', [ __CLASS__, 'register' ] );
    }

    public static function permission_check() {
        $s = Taxi135_TM_Client::settings();
        if ( ! empty( $s['allow_public'] ) ) { return true; }
        if ( current_user_can( 'read' ) ) { return true; }
        return new WP_Error( 'taxi135_forbidden', 'Требуется вход в WordPress.', [ 'status' => 401 ] );
    }

    public static function register() {
        $args = [ 'permission_callback' => [ __CLASS__, 'permission_check' ] ];

        /* ---- Simple GET lookups ---- */
        $get_routes = [
            'crew-groups'    => [ 'get_crew_groups_list', 'crew_groups' ],
            'crew-states'    => [ 'get_crew_states_list', 'crew_states' ],
            'order-states'   => [ 'get_order_states_list', 'order_states' ],
            'tariffs'        => [ 'get_tariffs_list', 'tariffs' ],
            'crews'          => [ 'get_crews_info', 'crews_info' ],
            'crews/coords'   => [ 'get_crews_coords', 'crews_coords' ],
            'drivers'        => [ 'get_drivers_info', 'drivers_info' ],
            'orders/current' => [ 'get_current_orders', 'orders' ],
        ];
        foreach ( $get_routes as $route => $cfg ) {
            register_rest_route( TAXI135_REST_NS, '/' . $route, array_merge( $args, [
                'methods'  => 'GET',
                'callback' => function () use ( $cfg ) {
                    return self::wrap( function () use ( $cfg ) {
                        $data = Taxi135_TM_Client::get( $cfg[0] );
                        return [ 'items' => isset( $data[ $cfg[1] ] ) ? $data[ $cfg[1] ] : [] ];
                    } );
                },
            ] ) );
        }

        /* ---- Finished orders ---- */
        register_rest_route( TAXI135_REST_NS, '/orders/finished', array_merge( $args, [
            'methods'  => 'GET',
            'args'     => [
                'start_time'  => [ 'type' => 'string', 'default' => '' ],
                'finish_time' => [ 'type' => 'string', 'default' => '' ],
                'driver_id'   => [ 'type' => 'integer', 'default' => 0 ],
            ],
            'callback' => function ( WP_REST_Request $req ) {
                /* Читаем параметры всеми возможными способами */
                $qp    = $req->get_query_params();
                $start = isset( $qp['start_time'] )  ? trim( (string) $qp['start_time'] )  : '';
                $end   = isset( $qp['finish_time'] )  ? trim( (string) $qp['finish_time'] )  : '';

                if ( $start === '' ) { $start = trim( (string) $req->get_param('start_time') ); }
                if ( $end   === '' ) { $end   = trim( (string) $req->get_param('finish_time') ); }
                if ( $start === '' && isset( $_GET['start_time'] ) )  { $start = sanitize_text_field( $_GET['start_time'] ); }
                if ( $end   === '' && isset( $_GET['finish_time'] ) )  { $end   = sanitize_text_field( $_GET['finish_time'] ); }

                /* Принимаем устаревший end_time как псевдоним finish_time (обратная совместимость) */
                if ( $end === '' ) { $end = isset( $qp['end_time'] ) ? trim( (string) $qp['end_time'] ) : ''; }
                if ( $end === '' ) { $end = trim( (string) $req->get_param('end_time') ); }
                if ( $end === '' && isset( $_GET['end_time'] ) ) { $end = sanitize_text_field( $_GET['end_time'] ); }

                if ( $start === '' || $end === '' ) {
                    return new WP_Error( 'taxi135_bad_request',
                        'start_time и finish_time обязательны (YYYYMMDDHHmmSS)',
                        [ 'status' => 400 ] );
                }
                $driver_id = (int) ( $qp['driver_id'] ?? $req->get_param('driver_id') ?? 0 );
                return self::wrap( function () use ( $start, $end, $driver_id ) {
                    $orders = self::fetch_finished_orders( $start, $end, $driver_id > 0 ? $driver_id : null );
                    /* PHP вычисляет стоимость заказа сразу — JS просто читает _cost */
                    foreach ( $orders as &$o ) {
                        $c = 0.0;
                        foreach ( [ 'sum', 'total_sum', 'cost', 'order_sum', 'total', 'price', 'amount', 'fare', 'cost_client', 'client_cost', 'cash_sum' ] as $_f ) {
                            if ( isset( $o[ $_f ] ) && floatval( $o[ $_f ] ) > 0 ) { $c = floatval( $o[ $_f ] ); break; }
                        }
                        $o['_cost'] = $c;
                    }
                    unset( $o );
                    return [ 'items' => $orders ];
                } );
            },
        ] ) );

        /* ---- Today stats ---- */
        register_rest_route( TAXI135_REST_NS, '/stats/today', array_merge( $args, [
            'methods'  => 'GET',
            'callback' => function () {
                return self::wrap( function () {
                    $now    = new DateTime();
                    $start  = ( clone $now )->setTime( 0, 0, 0 )->format( 'YmdHis' );
                    $end    = $now->format( 'YmdHis' );
                    $orders = self::fetch_finished_orders( $start, $end );
                    $count  = count( $orders );
                    $total  = 0.0;
                    $drivers_earn = [];
                    foreach ( $orders as $o ) {
                        /* ?? пропускает только null, а не 0 — поэтому используем цикл */
                        $cost = 0.0;
                        foreach ( [ 'sum', 'total_sum', 'cost', 'order_sum', 'total', 'price', 'amount', 'fare', 'cost_client', 'client_cost', 'cash_sum' ] as $_f ) {
                            if ( isset( $o[ $_f ] ) && floatval( $o[ $_f ] ) > 0 ) {
                                $cost = floatval( $o[ $_f ] );
                                break;
                            }
                        }
                        $total += $cost;
                        $did = $o['driver_id'] ?? '';
                        if ( $did ) {
                            if ( ! isset( $drivers_earn[ $did ] ) ) {
                                $drivers_earn[ $did ] = [
                                    'driver_id' => $did,
                                    'name'      => $o['driver_name'] ?? '',
                                    'count'     => 0,
                                    'sum'       => 0.0,
                                ];
                            }
                            $drivers_earn[ $did ]['count']++;
                            $drivers_earn[ $did ]['sum'] += $cost;
                        }
                    }
                    usort( $drivers_earn, function ( $a, $b ) { return $b['sum'] <=> $a['sum']; } );
                    return [
                        'orders_count' => $count,
                        'orders_sum'   => round( $total, 2 ),
                        'top_drivers'  => array_slice( array_values( $drivers_earn ), 0, 5 ),
                        'date'         => ( new DateTime() )->format( 'd.m.Y' ),
                    ];
                } );
            },
        ] ) );

        /* ---- Driver messages (incoming from TMDriver) ---- */
        /*
         * TaxiMaster API (help.taximaster.ru/index.php/TM_API) не предоставляет
         * публичного метода для чтения входящих сообщений от водителей (TMDriver).
         * Сообщения TMDriver → диспетчер хранятся в ТМ и доступны только через
         * интерфейс диспетчерского ПО.
         * Endpoint намеренно возвращает пустой список с пояснением.
         */
        register_rest_route( TAXI135_REST_NS, '/messages', array_merge( $args, [
            'methods'  => 'GET',
            'callback' => function () {
                return rest_ensure_response( [
                    'items'     => [],
                    'supported' => false,
                    'note'      => 'TaxiMaster API не предоставляет метода для чтения входящих сообщений от водителей (TMDriver). '
                                 . 'Просматривайте сообщения в диспетчерском ПО Такси-Мастер.',
                ] );
            },
        ] ) );

        /* ---- Driver ratings ---- */
        register_rest_route( TAXI135_REST_NS, '/drivers/ratings', array_merge( $args, [
            'methods'  => 'GET',
            'callback' => function () {
                return self::wrap( function () {
                    try {
                        $data  = Taxi135_TM_Client::get( 'get_driver_rating' );
                        $items = $data['driver_ratings'] ?? $data['ratings'] ?? $data['drivers'] ?? [];
                        return [ 'items' => is_array( $items ) ? array_values( $items ) : [] ];
                    } catch ( Throwable $e ) {
                        $data    = Taxi135_TM_Client::get( 'get_drivers_info' );
                        $drivers = $data['drivers_info'] ?? [];
                        $result  = [];
                        foreach ( $drivers as $d ) {
                            $result[] = [
                                'driver_id' => $d['driver_id'] ?? $d['id'] ?? '',
                                'name'      => $d['name'] ?? '',
                                'rating'    => $d['rating'] ?? $d['mark'] ?? null,
                                'trips'     => $d['trips_count'] ?? $d['orders_count'] ?? null,
                                'balance'   => $d['balance'] ?? null,
                            ];
                        }
                        return [ 'items' => $result ];
                    }
                } );
            },
        ] ) );

        /* ---- Change order state ---- */
        register_rest_route( TAXI135_REST_NS, '/orders/(?P<id>\d+)/state', array_merge( $args, [
            'methods'  => 'POST',
            'callback' => function ( WP_REST_Request $req ) {
                $id   = (int) $req['id'];
                $body = $req->get_json_params();
                if ( ! is_array( $body ) ) { $body = $req->get_params(); }
                $state_id = isset( $body['state_id'] ) ? (int) $body['state_id'] : 0;
                if ( ! $id || ! $state_id ) {
                    return new WP_Error( 'taxi135_bad_request', 'id и state_id обязательны', [ 'status' => 400 ] );
                }
                return self::wrap( function () use ( $id, $state_id ) {
                    Taxi135_TM_Client::post( 'change_order_state', [
                        'order_id' => $id,
                        'state_id' => $state_id,
                    ] );
                    return [ 'ok' => true ];
                } );
            },
        ] ) );

        /* ---- Edit order ---- */
        register_rest_route( TAXI135_REST_NS, '/orders/(?P<id>\d+)', array_merge( $args, [
            'methods'  => 'POST',
            'callback' => function ( WP_REST_Request $req ) {
                $id   = (int) $req['id'];
                $body = $req->get_json_params();
                if ( ! is_array( $body ) ) { $body = $req->get_params(); }
                if ( ! $id ) {
                    return new WP_Error( 'taxi135_bad_request', 'id обязателен', [ 'status' => 400 ] );
                }
                return self::wrap( function () use ( $id, $body ) {
                    $params = [ 'order_id' => $id ];
                    foreach ( [ 'source', 'destination', 'customer', 'phone', 'comment', 'source_time' ] as $k ) {
                        if ( isset( $body[ $k ] ) && trim( (string) $body[ $k ] ) !== '' ) {
                            $params[ $k ] = trim( (string) $body[ $k ] );
                        }
                    }
                    $data = Taxi135_TM_Client::post( 'edit_order', $params );
                    return [ 'ok' => true, 'data' => $data ];
                } );
            },
        ] ) );

        /* ---- Create order ---- */
        register_rest_route( TAXI135_REST_NS, '/orders', array_merge( $args, [
            'methods'  => 'POST',
            'callback' => function ( WP_REST_Request $req ) {
                $body   = $req->get_json_params();
                if ( ! is_array( $body ) ) { $body = $req->get_params(); }
                $phone  = isset( $body['phone'] )  ? trim( (string) $body['phone'] )  : '';
                $source = isset( $body['source'] ) ? trim( (string) $body['source'] ) : '';
                if ( $phone === '' || $source === '' ) {
                    return new WP_Error( 'taxi135_bad_request', 'phone и source обязательны', [ 'status' => 400 ] );
                }
                $phone_clean = preg_replace( '/[^\d]/', '', $phone );
                if ( strpos( $phone_clean, '00' ) === 0 ) { $phone_clean = substr( $phone_clean, 2 ); }
                $now      = new DateTime();
                $src_time = ( isset( $body['source_time'] ) && trim( (string) $body['source_time'] ) !== '' )
                    ? trim( (string) $body['source_time'] ) : $now->format( 'YmdHis' );
                $params = [ 'phone' => $phone_clean, 'source' => $source, 'source_time' => $src_time ];
                if ( isset( $body['destination'] ) && trim( (string) $body['destination'] ) !== '' ) {
                    $params['dest'] = trim( (string) $body['destination'] );
                }
                foreach ( [ 'customer', 'comment' ] as $k ) {
                    if ( isset( $body[ $k ] ) && trim( (string) $body[ $k ] ) !== '' ) {
                        $params[ $k ] = trim( (string) $body[ $k ] );
                    }
                }
                return self::wrap( function () use ( $params ) {
                    $data = Taxi135_TM_Client::post( 'create_order', $params );
                    return [ 'ok' => true, 'data' => $data ];
                } );
            },
        ] ) );

        /* ---- Driver balance ---- */
        register_rest_route( TAXI135_REST_NS, '/drivers/(?P<id>\d+)/balance', array_merge( $args, [
            'methods'  => 'POST',
            'callback' => function ( WP_REST_Request $req ) {
                $id   = (int) $req['id'];
                $body = $req->get_json_params();
                if ( ! is_array( $body ) ) { $body = $req->get_params(); }
                $amount = isset( $body['amount'] ) ? (float) $body['amount'] : null;
                if ( ! $id || $amount === null ) {
                    return new WP_Error( 'taxi135_bad_request', 'id и amount обязательны', [ 'status' => 400 ] );
                }
                return self::wrap( function () use ( $id, $amount, $body ) {
                    $abs  = abs( $amount );
                    $desc = ! empty( $body['description'] ) ? trim( (string) $body['description'] ) : '';

                    /*
                     * TaxiMaster API: create_driver_operation
                     * oper_type: 0 = приход (пополнение), 1 = расход (списание)
                     *
                     * ИСПРАВЛЕНО v3.2.1: расширен список комбинаций параметров.
                     * Некоторые версии сервера требуют другие имена полей или
                     * числовые значения oper_type начиная с 1, а не с 0.
                     */
                    $combos = [
                        /* Вариант 1: oper_type числом 0/1 (пополнение=0, списание=1) */
                        [
                            'driver_id' => $id,
                            'oper_sum'  => $abs,
                            'oper_type' => $amount >= 0 ? 0 : 1,
                        ],
                        /* Вариант 2: oper_type числом 1/2 (пополнение=1, списание=2) */
                        [
                            'driver_id' => $id,
                            'oper_sum'  => $abs,
                            'oper_type' => $amount >= 0 ? 1 : 2,
                        ],
                        /* Вариант 3: oper_type строкой receipt/expense */
                        [
                            'driver_id' => $id,
                            'oper_sum'  => $abs,
                            'oper_type' => $amount >= 0 ? 'receipt' : 'expense',
                        ],
                        /* Вариант 4: type вместо oper_type */
                        [
                            'driver_id' => $id,
                            'oper_sum'  => $abs,
                            'type'      => $amount >= 0 ? 0 : 1,
                        ],
                        /* Вариант 5: параметр sum вместо oper_sum */
                        [
                            'driver_id' => $id,
                            'sum'       => $amount,
                            'oper_type' => $amount >= 0 ? 0 : 1,
                        ],
                        /* Вариант 6: только driver_id и sum (минимальный запрос) */
                        [
                            'driver_id' => $id,
                            'sum'       => $amount,
                        ],
                        /* Вариант 7: amount вместо sum/oper_sum */
                        [
                            'driver_id' => $id,
                            'amount'    => $amount,
                            'oper_type' => $amount >= 0 ? 0 : 1,
                        ],
                    ];

                    $last_err = null;
                    foreach ( $combos as $params ) {
                        if ( $desc !== '' ) {
                            $params['name']    = $desc;
                            $params['comment'] = $desc;
                        }
                        try {
                            $data = Taxi135_TM_Client::post( 'create_driver_operation', $params );
                            return [ 'ok' => true, 'data' => $data ];
                        } catch ( Taxi135_TM_Exception $e ) {
                            $last_err = $e;
                            /* Если ошибка "не найден метод" — нет смысла пробовать другие варианты параметров */
                            if ( $e->api_code === 6 || $e->api_code === 404 || stripos( $e->api_descr, 'method' ) !== false ) {
                                break;
                            }
                            continue;
                        } catch ( Throwable $e ) {
                            $last_err = $e;
                            continue;
                        }
                    }

                    /* Последние попытки: альтернативные имена метода */
                    $alt_methods = [
                        [ 'add_driver_balance',    [ 'driver_id' => $id, 'sum'    => $amount ] ],
                        [ 'driver_balance_add',    [ 'driver_id' => $id, 'sum'    => $abs, 'type' => $amount >= 0 ? 'in' : 'out' ] ],
                        [ 'change_driver_balance', [ 'driver_id' => $id, 'amount' => $amount ] ],
                    ];
                    foreach ( $alt_methods as $am ) {
                        try {
                            $p = $am[1];
                            if ( $desc !== '' ) { $p['comment'] = $desc; }
                            $data = Taxi135_TM_Client::post( $am[0], $p );
                            return [ 'ok' => true, 'data' => $data ];
                        } catch ( Throwable $e2 ) {
                            $last_err = $last_err ?? $e2;
                        }
                    }

                    if ( $last_err ) { throw $last_err; }
                    throw new RuntimeException( 'Не удалось выполнить операцию с балансом' );
                } );
            },
        ] ) );

        /*
         * Endpoint /drivers/{id}/message оставлен для обратной совместимости,
         * но на этом сервере send_driver_message возвращает Код 6 (метод не существует).
         * Кнопка «Сообщение» убрана из UI. Если метод появится в будущем — автоматически заработает.
         */
        register_rest_route( TAXI135_REST_NS, '/drivers/(?P<id>\d+)/message', array_merge( $args, [
            'methods'  => 'POST',
            'callback' => function ( WP_REST_Request $req ) {
                $id   = (int) $req['id'];
                $body = $req->get_json_params();
                if ( ! is_array( $body ) ) { $body = $req->get_params(); }
                $message = isset( $body['message'] ) ? trim( (string) $body['message'] ) : '';
                if ( ! $id || $message === '' ) {
                    return new WP_Error( 'taxi135_bad_request', 'id и message обязательны', [ 'status' => 400 ] );
                }
                return self::wrap( function () use ( $id, $message ) {
                    $send_combos = [
                        [ 'send_driver_message',    [ 'driver_id' => $id, 'message' => $message ] ],
                        [ 'send_driver_message',    [ 'id'        => $id, 'message' => $message ] ],
                        [ 'create_driver_message',  [ 'driver_id' => $id, 'message' => $message ] ],
                        [ 'send_message_to_driver', [ 'driver_id' => $id, 'message' => $message ] ],
                        [ 'send_push_message',      [ 'driver_id' => $id, 'message' => $message ] ],
                        [ 'notify_driver',          [ 'driver_id' => $id, 'message' => $message ] ],
                    ];
                    foreach ( $send_combos as $combo ) {
                        try {
                            $data = Taxi135_TM_Client::post( $combo[0], $combo[1] );
                            return [ 'ok' => true, 'method' => $combo[0], 'data' => $data ];
                        } catch ( Throwable $e ) {
                            if ( $e instanceof Taxi135_TM_Exception && $e->api_code === 6 ) { break; }
                            continue;
                        }
                    }
                    return new WP_Error( 'taxi135_no_method',
                        'Сервер TaxiMaster не поддерживает отправку сообщений водителям (Код 6). '
                        . 'Метод send_driver_message отсутствует на данном сервере.',
                        [ 'status' => 502 ] );
                } );
            },
        ] ) );

        /* ---- Dashboard aggregated ---- */
        register_rest_route( TAXI135_REST_NS, '/dashboard', array_merge( $args, [
            'methods'  => 'GET',
            'callback' => function () {
                return self::wrap( function () {
                    $crews_data  = Taxi135_TM_Client::get( 'get_crews_info' );
                    $states_data = Taxi135_TM_Client::get( 'get_crew_states_list' );
                    $groups_data = Taxi135_TM_Client::get( 'get_crew_groups_list' );
                    $crews  = $crews_data['crews_info']   ?? [];
                    $states = $states_data['crew_states'] ?? [];
                    $groups = $groups_data['crew_groups'] ?? [];
                    $state_by_id = [];
                    foreach ( $states as $s ) { $state_by_id[ $s['id'] ] = $s; }
                    $group_by_id = [];
                    foreach ( $groups as $g ) { $group_by_id[ $g['id'] ] = $g; }
                    $total = count( $crews ); $online = 0; $free = 0; $on_order = 0;
                    $by_state = []; $by_group = [];
                    foreach ( $crews as $c ) {
                        if ( ! empty( $c['online'] ) ) { $online++; }
                        $st   = $state_by_id[ $c['crew_state_id'] ] ?? null;
                        $kind = $st ? (string) $st['state_type'] : '';
                        if ( $kind === 'free' ) { $free++; }
                        if ( $kind === 'on_order' || $kind === 'busy' ) { $on_order++; }
                        $sid = (int) $c['crew_state_id'];
                        if ( ! isset( $by_state[ $sid ] ) ) {
                            $by_state[ $sid ] = [ 'state_id' => $sid, 'state_name' => $st ? $st['name'] : ( '#' . $sid ), 'count' => 0 ];
                        }
                        $by_state[ $sid ]['count']++;
                        $gid = (int) $c['crew_group_id'];
                        $g   = $group_by_id[ $gid ] ?? null;
                        if ( ! isset( $by_group[ $gid ] ) ) {
                            $by_group[ $gid ] = [ 'group_id' => $gid, 'group_name' => $g ? $g['name'] : ( '#' . $gid ), 'count' => 0 ];
                        }
                        $by_group[ $gid ]['count']++;
                    }
                    return [
                        'total_crews'    => $total,
                        'online_crews'   => $online,
                        'free_crews'     => $free,
                        'on_order_crews' => $on_order,
                        'crews_by_state' => array_values( $by_state ),
                        'crews_by_group' => array_values( $by_group ),
                    ];
                } );
            },
        ] ) );

        /* ---- Public endpoints ---- */
        register_rest_route( TAXI135_REST_NS, '/pub/crews-coords', [
            'methods'             => 'GET',
            'permission_callback' => '__return_true',
            'callback'            => function () {
                return self::wrap( function () {
                    $data = Taxi135_TM_Client::get( 'get_crews_coords' );
                    return [ 'items' => $data['crews_coords'] ?? [] ];
                } );
            },
        ] );

        register_rest_route( TAXI135_REST_NS, '/pub/order', [
            'methods'             => 'POST',
            'permission_callback' => '__return_true',
            'callback'            => function ( WP_REST_Request $req ) {
                $body   = $req->get_json_params();
                if ( ! is_array( $body ) ) { $body = $req->get_params(); }
                $phone  = isset( $body['phone'] )  ? trim( (string) $body['phone'] )  : '';
                $source = isset( $body['source'] ) ? trim( (string) $body['source'] ) : '';
                if ( $phone === '' || $source === '' ) {
                    return new WP_Error( 'taxi135_bad_request', 'Укажите телефон и адрес подачи.', [ 'status' => 400 ] );
                }
                $phone_clean = preg_replace( '/[^\d]/', '', $phone );
                if ( strpos( $phone_clean, '00' ) === 0 ) { $phone_clean = substr( $phone_clean, 2 ); }
                $now      = new DateTime();
                $src_time = ( isset( $body['source_time'] ) && trim( (string) $body['source_time'] ) !== '' )
                    ? trim( (string) $body['source_time'] ) : $now->format( 'YmdHis' );
                $params = [ 'phone' => $phone_clean, 'source' => $source, 'source_time' => $src_time ];
                if ( isset( $body['destination'] ) && trim( (string) $body['destination'] ) !== '' ) {
                    $params['dest'] = trim( (string) $body['destination'] );
                }
                foreach ( [ 'customer', 'comment' ] as $k ) {
                    if ( isset( $body[ $k ] ) && trim( (string) $body[ $k ] ) !== '' ) {
                        $params[ $k ] = trim( (string) $body[ $k ] );
                    }
                }
                return self::wrap( function () use ( $params ) {
                    $data = Taxi135_TM_Client::post( 'create_order', $params );
                    return [ 'ok' => true, 'data' => $data ];
                } );
            },
        ] );

        /* ---- Ping ---- */
        register_rest_route( TAXI135_REST_NS, '/ping', [
            'methods'             => 'GET',
            'permission_callback' => function () { return current_user_can( 'manage_options' ); },
            'callback'            => function () {
                return self::wrap( function () {
                    $data = Taxi135_TM_Client::get( 'get_tariffs_list' );
                    return [ 'ok' => true, 'tariffs_count' => isset( $data['tariffs'] ) ? count( $data['tariffs'] ) : 0 ];
                } );
            },
        ] );

        /* ---- Diagnostics ---- */
        register_rest_route( TAXI135_REST_NS, '/diag', [
            'methods'             => 'GET',
            'permission_callback' => function () { return current_user_can( 'manage_options' ); },
            'callback'            => function () {
                return rest_ensure_response( self::run_diagnostics() );
            },
        ] );
    }

    /**
     * Получить выполненные заказы за период.
     *
     * ИСПРАВЛЕНО v3.2.2:
     *   — Правильные имена параметров согласно официальной документации TaxiMaster API:
     *       start_time + finish_time (не end_time!)
     *   — Добавлены комбинации с обязательным фильтром (driver_id=0 / crew_id=0)
     *     для версий сервера, требующих хотя бы один фильтр помимо диапазона дат.
     *
     * @param string $start  YYYYMMDDHHmmSS
     * @param string $end    YYYYMMDDHHmmSS
     * @param int|null $driver_id  ID водителя (null = все водители)
     * @param int|null $crew_id    ID экипажа (null = все экипажи)
     * @return array
     * @throws Throwable
     */
    private static function fetch_finished_orders( $start, $end, $driver_id = null, $crew_id = null ) {
        /*
         * Правильные имена параметров по официальной документации TaxiMaster API:
         * https://help.taximaster.ru/index.php/TM_API
         *
         * Обязательные: start_time, finish_time
         * Условно обязательные (в некоторых версиях нужен хотя бы один):
         *   driver_id | crew_id | client_id | phone
         *
         * Перебираем комбинации от «правильной по документации»
         * до запасных для старых версий сервера.
         */
        /*
         * Явно запрашиваем поля суммы по документации TaxiMaster API:
         * sum, total_sum — итоговая стоимость заказа (официальные поля v3.15+)
         * driver_id, driver_name — для группировки по водителям
         */
        $fields = 'sum,total_sum,cash_sum,cashless_sum,driver_id,driver_name,start_time,finish_time,source,destination,state_id,crew_id,client_name,phone';

        $combos = [];

        /* ── Вариант A: только диапазон дат + явные поля ── */
        $combos[] = [ 'start_time' => $start, 'finish_time' => $end, 'fields' => $fields ];

        /* ── Вариант A2: только диапазон дат без fields (fallback для старых серверов) ── */
        $combos[] = [ 'start_time' => $start, 'finish_time' => $end ];

        /* ── Вариант B: диапазон + конкретный водитель/экипаж (если передан) ── */
        if ( $driver_id !== null && $driver_id > 0 ) {
            $combos[] = [ 'start_time' => $start, 'finish_time' => $end, 'driver_id' => $driver_id, 'fields' => $fields ];
            $combos[] = [ 'start_time' => $start, 'finish_time' => $end, 'driver_id' => $driver_id ];
        }
        if ( $crew_id !== null && $crew_id > 0 ) {
            $combos[] = [ 'start_time' => $start, 'finish_time' => $end, 'crew_id' => $crew_id, 'fields' => $fields ];
            $combos[] = [ 'start_time' => $start, 'finish_time' => $end, 'crew_id' => $crew_id ];
        }

        /* ── Вариант C: диапазон + driver_id=0 («все водители» на серверах с обязательным фильтром) ── */
        $combos[] = [ 'start_time' => $start, 'finish_time' => $end, 'driver_id' => 0, 'fields' => $fields ];
        $combos[] = [ 'start_time' => $start, 'finish_time' => $end, 'driver_id' => 0 ];

        /* ── Запасные варианты для старых версий TaxiMaster ── */
        $combos[] = [ 'start_time' => $start, 'end_time'   => $end ];
        $combos[] = [ 'begin_time' => $start, 'finish_time' => $end ];
        $combos[] = [ 'begin_time' => $start, 'end_time'   => $end ];
        $combos[] = [ 'begin'      => $start, 'end'        => $end ];
        $combos[] = [ 'date_begin' => $start, 'date_end'   => $end ];
        $combos[] = [ 'date_from'  => $start, 'date_to'    => $end ];
        $combos[] = [ 'from'       => $start, 'to'         => $end ];
        $combos[] = [ 'time_from'  => $start, 'time_to'    => $end ];

        $last_err = null;
        foreach ( $combos as $params ) {
            try {
                $data   = Taxi135_TM_Client::get( 'get_finished_orders', $params );
                $orders = $data['orders'] ?? $data['finished_orders'] ?? $data['items'] ?? [];
                if ( is_array( $orders ) ) {
                    return $orders;
                }
            } catch ( Taxi135_TM_Exception $e ) {
                $last_err = $e;
                /* Если ошибка явно не про параметры — прекращаем перебор */
                $descr_lc = strtolower( $e->api_descr );
                $is_param_error = (
                    strpos( $descr_lc, 'parameter' ) !== false ||
                    strpos( $descr_lc, 'param' )     !== false ||
                    strpos( $descr_lc, 'missing' )   !== false ||
                    strpos( $descr_lc, 'required' )  !== false ||
                    strpos( $descr_lc, 'параметр' )  !== false ||
                    $e->api_code === 8
                );
                if ( ! $is_param_error ) { break; }
                continue;
            } catch ( Throwable $e ) {
                $last_err = $e;
                break;
            }
        }

        if ( $last_err ) { throw $last_err; }
        return [];
    }

    /**
     * Диагностика: опрашивает сервер TaxiMaster по всем методам.
     *
     * ИСПРАВЛЕНО v3.2.2:
     *   — Правильное имя параметра: finish_time (не end_time) — по официальной документации
     *   — Добавлены комбинации с driver_id=0 для серверов с обязательным фильтром
     *   — Раздел сообщений TMDriver: чёткое пояснение, что API не предоставляет
     *     метод для чтения входящих сообщений (только через интерфейс ТМ)
     */
    private static function run_diagnostics() {
        $now   = new DateTime();
        $start = ( clone $now )->setTime( 0, 0, 0 )->format( 'YmdHis' );
        $end   = $now->format( 'YmdHis' );

        /* Вспомогательная функция — один тест */
        $test = function ( $label, callable $fn ) {
            try {
                $fn();
                return [ 'ok' => true, 'note' => 'Работает' ];
            } catch ( Taxi135_TM_Exception $e ) {
                $note = 'Код ' . $e->api_code . ': ' . ( $e->api_descr ?: $e->getMessage() );
                if ( $e->api_code === 6 )  { $note .= ' — метод отсутствует на этом сервере'; }
                if ( $e->api_code === 7 )  { $note .= ' — неверный метод HTTP (GET/POST)'; }
                if ( $e->api_code === 8 )  { $note .= ' — отсутствует обязательный параметр'; }
                if ( $e->api_code === 10 ) { $note .= ' — внутренняя ошибка (при диагностике driver_id=1 может не существовать; в реальной работе ошибки нет)'; }
                return [ 'ok' => false, 'note' => $note ];
            } catch ( Throwable $e ) {
                return [ 'ok' => false, 'note' => $e->getMessage() ];
            }
        };

        /* ── Базовые справочники ── */
        $base = [];
        foreach ( [
            'get_tariffs_list'      => 'Тарифы',
            'get_crew_groups_list'  => 'Группы экипажей',
            'get_crew_states_list'  => 'Статусы экипажей',
            'get_order_states_list' => 'Статусы заказов',
            'get_crews_info'        => 'Список экипажей',
            'get_crews_coords'      => 'Координаты экипажей',
            'get_drivers_info'      => 'Список водителей',
            'get_current_orders'    => 'Текущие заказы',
        ] as $method => $label ) {
            $r = $test( $label, function () use ( $method ) {
                Taxi135_TM_Client::get( $method );
            } );
            $base[] = array_merge( [ 'method' => $method, 'label' => $label ], $r );
        }

        /* ── Выполненные заказы ── */
        $finished = [];

        /*
         * Правильные имена параметров по официальной документации:
         *   start_time + finish_time
         * Дополнительно пробуем с driver_id=0 (для серверов с обязательным фильтром)
         * и запасные имена параметров для старых версий ТМ.
         */
        $diag_combos = [
            'start_time + finish_time (официальный)'               => [ 'start_time' => $start, 'finish_time' => $end ],
            'start_time + finish_time + driver_id=0 (все водители)' => [ 'start_time' => $start, 'finish_time' => $end, 'driver_id' => 0 ],
            'start_time + end_time (устаревший)'                    => [ 'start_time' => $start, 'end_time'    => $end ],
            'begin_time + finish_time'                              => [ 'begin_time' => $start, 'finish_time' => $end ],
            'begin_time + end_time'                                 => [ 'begin_time' => $start, 'end_time'    => $end ],
            'date_from + date_to'                                   => [ 'date_from'  => $start, 'date_to'     => $end ],
            'from + to'                                             => [ 'from'       => $start, 'to'          => $end ],
        ];

        foreach ( $diag_combos as $label => $params ) {
            $r = $test( $label, function () use ( $params ) {
                Taxi135_TM_Client::get( 'get_finished_orders', $params );
            } );
            $finished[] = array_merge( [ 'method' => 'get_finished_orders(' . $label . ')' ], $r );
            if ( $r['ok'] ) { break; }
        }

        /* ── Операции с балансом ── */
        $balance = [];
        $balance_combos = [
            'create_driver_operation(oper_type=0)'          => [ 'driver_id' => 1, 'oper_sum' => 0.01, 'oper_type' => 0 ],
            'create_driver_operation(oper_type=1)'           => [ 'driver_id' => 1, 'oper_sum' => 0.01, 'oper_type' => 1 ],
            'create_driver_operation(oper_type="receipt")'   => [ 'driver_id' => 1, 'oper_sum' => 0.01, 'oper_type' => 'receipt' ],
            'create_driver_operation(sum=)'                  => [ 'driver_id' => 1, 'sum' => 0.01 ],
        ];
        foreach ( $balance_combos as $label => $params ) {
            $r = $test( $label, function () use ( $params ) {
                Taxi135_TM_Client::post( 'create_driver_operation', $params );
            } );
            $balance[] = array_merge( [ 'method' => $label ], $r );
        }
        $r = $test( 'add_driver_balance', function () {
            Taxi135_TM_Client::post( 'add_driver_balance', [ 'driver_id' => 1, 'sum' => 0.01 ] );
        } );
        $balance[] = array_merge( [ 'method' => 'add_driver_balance(driver_id, sum)' ], $r );

        /*
         * ── Сообщения TMDriver (входящие от водителей) ──
         *
         * Согласно официальной документации TaxiMaster API (help.taximaster.ru/index.php/TM_API),
         * метода для чтения входящих сообщений от водителей (TMDriver → диспетчер)
         * в открытом API НЕТ. Сообщения доступны только через интерфейс диспетчерского ПО
         * Такси-Мастер. Ниже — информационные строки для справки.
         */
        $incoming = [
            [
                'method' => 'Входящие сообщения от водителей (TMDriver)',
                'ok'     => false,
                'note'   => 'TaxiMaster API не предоставляет метод для чтения сообщений от водителей. '
                          . 'Сообщения TMDriver → диспетчер доступны только в интерфейсе ТМ. '
                          . 'Это не ошибка плагина — ограничение самого API.',
            ],
        ];

        /* ── Итог ── */
        return [
            'groups' => [
                [ 'title' => '📋 Базовые справочники и заказы', 'items' => $base ],
                [ 'title' => '📅 Выполненные заказы — параметры (правильный: start_time + finish_time)', 'items' => $finished ],
                [ 'title' => '💰 Баланс водителя (Код 10 = тестовый driver_id=1; в реальной работе норма)', 'items' => $balance ],
                [ 'title' => '📥 Сообщения TMDriver → диспетчер', 'items' => $incoming ],
            ],
        ];
    }

    private static function wrap( callable $fn ) {
        try {
            return rest_ensure_response( $fn() );
        } catch ( Taxi135_TM_Exception $e ) {
            return new WP_Error( 'taxi135_tm_api',
                $e->api_descr ?: $e->getMessage(),
                [ 'status' => 502, 'code' => $e->api_code, 'data' => $e->api_data ] );
        } catch ( Throwable $e ) {
            return new WP_Error( 'taxi135_tm_unreachable', $e->getMessage(), [ 'status' => 502 ] );
        }
    }
}
