<?php
/**
 * Страница настроек в wp-admin → Настройки → Такси 135.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Taxi135_Admin {

    public static function init() {
        add_action( 'admin_menu',  [ __CLASS__, 'menu' ] );
        add_action( 'admin_init', [ __CLASS__, 'register_settings' ] );
        add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue' ] );
        self::upgrade_settings();
    }

    public static function menu() {
        add_options_page(
            'Такси 135 — настройки',
            'Такси 135',
            'manage_options',
            'taxi135-settings',
            [ __CLASS__, 'render' ]
        );
    }

    public static function enqueue( $hook ) {
        if ( $hook !== 'settings_page_taxi135-settings' ) { return; }
        wp_enqueue_style(
            'taxi135-admin',
            TAXI135_PLUGIN_URL . 'assets/css/admin-diag.css',
            [],
            TAXI135_VERSION
        );
    }

    public static function register_settings() {
        register_setting( 'taxi135_group', TAXI135_OPTION, [
            'type'              => 'array',
            'sanitize_callback' => [ __CLASS__, 'sanitize' ],
            'default'           => [],
        ] );
    }

    public static function upgrade_settings() {
        $opt = get_option( TAXI135_OPTION, null );
        if ( ! is_array( $opt ) ) return;
        $defaults = [
            'host'               => '',
            'user_id'            => '',
            'secret'             => '',
            'allow_public'       => 0,
            'viber_dispatcher'   => '',
            'director_contact'   => '',
            'public_order_title' => 'Вызвать такси',
            'public_map_zoom'    => 13,
            'public_map_lat'     => 53.9,
            'public_map_lng'     => 27.5667,
        ];
        $changed = false;
        foreach ( $defaults as $k => $v ) {
            if ( ! array_key_exists( $k, $opt ) ) { $opt[ $k ] = $v; $changed = true; }
        }
        if ( $changed ) update_option( TAXI135_OPTION, $opt );
    }

    public static function sanitize( $input ) {
        $current = get_option( TAXI135_OPTION, [] );
        $out = wp_parse_args( is_array( $current ) ? $current : [], [
            'host' => '', 'user_id' => '', 'secret' => '', 'allow_public' => 0,
            'viber_dispatcher' => '', 'director_contact' => '',
            'public_order_title' => 'Вызвать такси',
            'public_map_zoom' => 13, 'public_map_lat' => 53.9, 'public_map_lng' => 27.5667,
        ] );

        foreach ( [ 'host', 'user_id', 'public_order_title' ] as $k ) {
            if ( isset( $input[ $k ] ) ) { $out[ $k ] = sanitize_text_field( $input[ $k ] ); }
        }
        foreach ( [ 'viber_dispatcher', 'director_contact' ] as $k ) {
            if ( isset( $input[ $k ] ) ) { $out[ $k ] = esc_url_raw( trim( $input[ $k ] ) ); }
        }
        foreach ( [ 'public_map_lat', 'public_map_lng' ] as $k ) {
            if ( isset( $input[ $k ] ) ) { $out[ $k ] = floatval( $input[ $k ] ); }
        }
        if ( isset( $input['public_map_zoom'] ) ) { $out['public_map_zoom'] = (int) $input['public_map_zoom']; }
        if ( isset( $input['secret'] ) && $input['secret'] !== '' ) {
            $out['secret'] = sanitize_text_field( $input['secret'] );
        }
        $out['allow_public'] = ! empty( $input['allow_public'] ) ? 1 : 0;
        return $out;
    }

    public static function render() {
        if ( ! current_user_can( 'manage_options' ) ) { return; }
        $opt = wp_parse_args( get_option( TAXI135_OPTION, [] ), [
            'host' => '', 'user_id' => '', 'secret' => '', 'allow_public' => 0,
            'viber_dispatcher' => '', 'director_contact' => '',
            'public_order_title' => 'Вызвать такси',
            'public_map_zoom' => 13, 'public_map_lat' => 53.9, 'public_map_lng' => 27.5667,
        ] );

        $rest_base   = esc_js( rest_url( TAXI135_REST_NS ) );
        $nonce       = esc_js( wp_create_nonce( 'wp_rest' ) );
        $ping_url    = esc_js( rest_url( TAXI135_REST_NS . '/ping' ) );
        $diag_url    = esc_js( rest_url( TAXI135_REST_NS . '/diag' ) );
        ?>
        <div class="wrap">
            <h1>⚙️ Такси 135 — Настройки</h1>

            <!-- ═══ НАСТРОЙКИ ═══ -->
            <form method="post" action="options.php">
                <?php settings_fields( 'taxi135_group' ); ?>
                <table class="form-table" role="presentation">
                    <tr><th colspan="2"><h2>🔗 Подключение TaxiMaster</h2></th></tr>
                    <tr>
                        <th><label for="t135_host">Хост API</label></th>
                        <td>
                            <input type="text" id="t135_host"
                                name="<?php echo esc_attr( TAXI135_OPTION ); ?>[host]"
                                value="<?php echo esc_attr( $opt['host'] ); ?>"
                                class="regular-text" placeholder="86.57.132.150:4055">
                            <p class="description">IP:порт вашего сервера TaxiMaster</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="t135_uid">User ID</label></th>
                        <td>
                            <input type="text" id="t135_uid"
                                name="<?php echo esc_attr( TAXI135_OPTION ); ?>[user_id]"
                                value="<?php echo esc_attr( $opt['user_id'] ); ?>" class="small-text">
                        </td>
                    </tr>
                    <tr>
                        <th><label for="t135_secret">Secret (MD5-ключ)</label></th>
                        <td>
                            <input type="password" id="t135_secret"
                                name="<?php echo esc_attr( TAXI135_OPTION ); ?>[secret]"
                                value="" class="regular-text"
                                placeholder="Оставьте пустым, чтобы не менять">
                            <p class="description">Оставьте пустым если не хотите менять сохранённый ключ.</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="t135_pub">Публичный доступ</label></th>
                        <td>
                            <label>
                                <input type="checkbox" id="t135_pub"
                                    name="<?php echo esc_attr( TAXI135_OPTION ); ?>[allow_public]"
                                    value="1" <?php checked( $opt['allow_public'], 1 ); ?>>
                                Разрешить без входа в WP
                            </label>
                            <p class="description">Внимание: API данных станет доступен без авторизации.</p>
                        </td>
                    </tr>
                    <tr><th colspan="2"><h2>📱 Публичный виджет</h2></th></tr>
                    <tr>
                        <th><label for="t135_pbt">Кнопка «Вызвать такси»</label></th>
                        <td>
                            <input type="text" id="t135_pbt"
                                name="<?php echo esc_attr( TAXI135_OPTION ); ?>[public_order_title]"
                                value="<?php echo esc_attr( $opt['public_order_title'] ); ?>"
                                class="regular-text">
                        </td>
                    </tr>
                    <tr>
                        <th><label for="t135_viber">Viber диспетчера (URL)</label></th>
                        <td>
                            <input type="url" id="t135_viber"
                                name="<?php echo esc_attr( TAXI135_OPTION ); ?>[viber_dispatcher]"
                                value="<?php echo esc_attr( $opt['viber_dispatcher'] ); ?>"
                                class="regular-text" placeholder="viber://chat?number=...">
                        </td>
                    </tr>
                    <tr>
                        <th><label for="t135_dir">Контакт директора (URL)</label></th>
                        <td>
                            <input type="url" id="t135_dir"
                                name="<?php echo esc_attr( TAXI135_OPTION ); ?>[director_contact]"
                                value="<?php echo esc_attr( $opt['director_contact'] ); ?>"
                                class="regular-text">
                        </td>
                    </tr>
                    <tr><th colspan="2"><h2>🗺️ Карта (публичный виджет)</h2></th></tr>
                    <tr>
                        <th>Центр карты (широта, долгота)</th>
                        <td>
                            <input type="number" step="0.0001"
                                name="<?php echo esc_attr( TAXI135_OPTION ); ?>[public_map_lat]"
                                value="<?php echo esc_attr( $opt['public_map_lat'] ); ?>" class="small-text"> ,
                            <input type="number" step="0.0001"
                                name="<?php echo esc_attr( TAXI135_OPTION ); ?>[public_map_lng]"
                                value="<?php echo esc_attr( $opt['public_map_lng'] ); ?>" class="small-text">
                        </td>
                    </tr>
                    <tr>
                        <th><label for="t135_zoom">Масштаб карты</label></th>
                        <td>
                            <input type="number" id="t135_zoom" min="5" max="19"
                                name="<?php echo esc_attr( TAXI135_OPTION ); ?>[public_map_zoom]"
                                value="<?php echo esc_attr( $opt['public_map_zoom'] ); ?>" class="small-text">
                        </td>
                    </tr>
                </table>
                <?php submit_button( 'Сохранить настройки' ); ?>
            </form>

            <hr>

            <!-- ═══ БЫСТРАЯ ПРОВЕРКА ═══ -->
            <h2>🔌 Проверка подключения</h2>
            <button type="button" class="button button-secondary" id="t135-ping-btn">
                Проверить соединение с TaxiMaster
            </button>
            <span id="t135-ping-result" style="margin-left:12px;font-weight:600;"></span>

            <hr>

            <!-- ═══ ДИАГНОСТИКА API ═══ -->
            <h2>🔍 Диагностика API методов</h2>
            <p class="description">
                Нажмите кнопку — плагин опросит ваш сервер TaxiMaster и покажет какие методы работают,
                а какие нет. Используйте это если видите ошибки в диспетчерской панели.
            </p>
            <button type="button" class="button button-primary" id="t135-diag-btn">
                🔍 Запустить диагностику
            </button>
            <span id="t135-diag-status" style="margin-left:12px;color:#888;"></span>
            <div id="t135-diag-result" style="margin-top:16px;"></div>

            <hr>
            <h2>📋 Использование</h2>
            <p>Для добавления диспетчерской панели используйте шорткод:</p>
            <code>[taxi135_dispatcher height="800px"]</code>
            <p>Для публичного виджета (карта + форма заказа):</p>
            <code>[taxi135_public height="500px"]</code>
        </div>

        <script>
        (function(){
            var REST  = '<?php echo $rest_base; ?>';
            var NONCE = '<?php echo $nonce; ?>';

            function apiFetch(url) {
                return fetch(url, {
                    headers: { 'X-WP-Nonce': NONCE, 'Accept': 'application/json' },
                    credentials: 'same-origin'
                }).then(function(r){ return r.json().then(function(j){ return { ok: r.ok, j: j }; }); });
            }

            /* ── Пинг ── */
            document.getElementById('t135-ping-btn').addEventListener('click', function(){
                var r = document.getElementById('t135-ping-result');
                r.style.color = '#888'; r.textContent = 'Проверка…';
                apiFetch('<?php echo $ping_url; ?>')
                    .then(function(d){
                        if (d.ok && d.j.ok) {
                            r.style.color = '#2a9d4b';
                            r.textContent = '✅ Подключено! Тарифов найдено: ' + (d.j.tariffs_count || 0);
                        } else {
                            r.style.color = '#c00';
                            r.textContent = '❌ Ошибка: ' + (d.j.message || 'неизвестная ошибка');
                        }
                    }).catch(function(e){ r.style.color='#c00'; r.textContent='❌ ' + e.message; });
            });

            /* ── Диагностика ── */
            document.getElementById('t135-diag-btn').addEventListener('click', function(){
                var btn  = this;
                var stat = document.getElementById('t135-diag-status');
                var out  = document.getElementById('t135-diag-result');
                btn.disabled = true;
                stat.textContent = 'Проверяем методы API… (может занять 10–30 сек)';
                out.innerHTML = '';

                apiFetch(REST + '/diag')
                    .then(function(d){
                        btn.disabled = false;
                        stat.textContent = '';
                        if (!d.ok) {
                            out.innerHTML = '<div class="t135-diag-error">Ошибка: ' + escH(d.j.message || 'неизвестная') + '</div>';
                            return;
                        }
                        var groups = d.j.groups || [];
                        var html = '<div class="t135-diag-wrap">';

                        /* Итог */
                        var total = 0, ok = 0;
                        groups.forEach(function(g){ g.items.forEach(function(it){ total++; if(it.ok) ok++; }); });
                        var pct = total ? Math.round(ok/total*100) : 0;
                        var cls = pct === 100 ? 'green' : pct >= 60 ? 'yellow' : 'red';
                        html += '<div class="t135-diag-summary t135-diag-' + cls + '">' +
                            '<strong>' + ok + ' / ' + total + ' методов работают (' + pct + '%)</strong>' +
                            (pct < 100 ? ' — отмеченные ❌ методы не поддерживаются вашим сервером.' : ' — всё в порядке!') +
                            '</div>';

                        groups.forEach(function(g){
                            html += '<div class="t135-diag-group">' +
                                '<div class="t135-diag-group-title">' + escH(g.title) + '</div>' +
                                '<table class="t135-diag-table"><tbody>';
                            g.items.forEach(function(it){
                                var icon = it.ok ? '✅' : '❌';
                                var cls2 = it.ok ? 'ok' : 'fail';
                                html += '<tr class="t135-diag-row ' + cls2 + '">' +
                                    '<td class="t135-diag-icon">' + icon + '</td>' +
                                    '<td class="t135-diag-method"><code>' + escH(it.method) + '</code></td>' +
                                    '<td class="t135-diag-note">' + escH(it.note) + '</td>' +
                                    '</tr>';
                            });
                            html += '</tbody></table></div>';
                        });

                        html += '</div>';
                        out.innerHTML = html;
                    })
                    .catch(function(e){
                        btn.disabled = false;
                        stat.textContent = '';
                        out.innerHTML = '<div class="t135-diag-error">Сетевая ошибка: ' + escH(e.message) + '</div>';
                    });
            });

            function escH(s) {
                return String(s||'').replace(/[&<>"']/g, function(c){
                    return({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c];
                });
            }
        })();
        </script>
        <?php
    }
}
