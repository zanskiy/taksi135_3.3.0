<?php
/**
 * Shortcode [taxi135_dispatcher] — диспетчерская панель.
 * Shortcode [taxi135_public]     — публичный виджет.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Taxi135_Shortcode {

    public static function init() {
        add_shortcode( 'taxi135_dispatcher', [ __CLASS__, 'render' ] );
    }

    public static function render( $atts = [] ) {
        $atts = shortcode_atts( [
            'height' => '900px',
        ], $atts, 'taxi135_dispatcher' );

        if ( ! Taxi135_TM_Client::is_configured() ) {
            return '<div class="t135-unconfigured">Кабинет «Такси 135» ещё не настроен. Откройте <em>Настройки → Такси 135</em> в WP-админке.</div>';
        }

        // Leaflet
        wp_enqueue_style(  'leaflet', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css', [], '1.9.4' );
        wp_enqueue_script( 'leaflet', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js',  [], '1.9.4', true );

        wp_enqueue_style(  'taxi135-dispatcher', TAXI135_PLUGIN_URL . 'assets/css/dispatcher.css', [ 'leaflet' ], TAXI135_VERSION );
        wp_enqueue_script( 'taxi135-dispatcher', TAXI135_PLUGIN_URL . 'assets/js/dispatcher.js',
            [ 'leaflet' ], TAXI135_VERSION, true );

        wp_localize_script( 'taxi135-dispatcher', 'TAXI135', [
            'restUrl' => esc_url_raw( rest_url( TAXI135_REST_NS . '/' ) ),
            'nonce'   => wp_create_nonce( 'wp_rest' ),
        ] );

        ob_start();
        $height = preg_match( '/^\d+(px|vh|em|%)?$/', $atts['height'] ) ? $atts['height'] : '900px';
        include TAXI135_PLUGIN_DIR . 'templates/dispatcher.php';
        $html = ob_get_clean();

        $style = '<style>.t135-app{height:' . esc_attr( $height ) . ';}</style>';
        return $style . $html;
    }
}


/**
 * Shortcode [taxi135_public] — публичный виджет для посетителей сайта.
 */
class Taxi135_Public_Shortcode {

    public static function init() {
        add_shortcode( 'taxi135_public', [ __CLASS__, 'render' ] );
    }

    public static function render( $atts = [] ) {
        $atts = shortcode_atts( [ 'height' => '520px' ], $atts, 'taxi135_public' );

        if ( ! Taxi135_TM_Client::is_configured() ) {
            return '<div style="padding:16px;background:#fff3cd;border:1px solid #ffc107;border-radius:6px;">
                &#9888; Плагин &#171;Такси 135&#187; ещё не настроен. Откройте <em>Настройки &rarr; Такси 135</em>.
            </div>';
        }

        $opt = wp_parse_args( get_option( TAXI135_OPTION, [] ), [
            'viber_dispatcher'   => '',
            'director_contact'   => '',
            'public_order_title' => 'Вызвать такси',
            'public_map_zoom'    => 13,
            'public_map_lat'     => 53.9,
            'public_map_lng'     => 27.5667,
        ] );

        wp_enqueue_style(  'leaflet',        'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css', [], '1.9.4' );
        wp_enqueue_script( 'leaflet',        'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js',  [], '1.9.4', true );
        wp_enqueue_style(  'taxi135-public', TAXI135_PLUGIN_URL . 'assets/css/public.css', [ 'leaflet' ], TAXI135_VERSION );
        wp_enqueue_script( 'taxi135-public', TAXI135_PLUGIN_URL . 'assets/js/public.js', [ 'leaflet' ], TAXI135_VERSION, true );

        wp_localize_script( 'taxi135-public', 'TAXI135PUB', [
            'restUrl'        => esc_url_raw( rest_url( TAXI135_REST_NS . '/pub/' ) ),
            'orderTitle'     => esc_html( $opt['public_order_title'] ),
            'viberUrl'       => esc_url_raw( $opt['viber_dispatcher'] ),
            'directorUrl'    => esc_url_raw( $opt['director_contact'] ),
            'mapLat'         => (float) $opt['public_map_lat'],
            'mapLng'         => (float) $opt['public_map_lng'],
            'mapZoom'        => (int)   $opt['public_map_zoom'],
        ] );

        $height = preg_match( '/^\d+(px|vh|em|%)?$/', $atts['height'] ) ? $atts['height'] : '520px';
        ob_start();
        include TAXI135_PLUGIN_DIR . 'templates/public.php';
        return ob_get_clean();
    }
}
