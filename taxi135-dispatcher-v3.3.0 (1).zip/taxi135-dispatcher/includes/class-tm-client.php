<?php
/**
 * TMAPI + TAPI client (cURL, MD5 signature, self-signed TLS).
 *
 * Протокол TaxiMaster common_api 1.0:
 *   signature = md5( query_string + secret )
 *   Подпись передаётся заголовком Signature: (не в query string и не в теле).
 *
 * ИСПРАВЛЕНО v3.2.1:
 *   — Добавлен метод get_with_uid() — включает user_id в query-строку
 *     (некоторые версии TaxiMaster требуют его в параметрах, не только в заголовке)
 *   — Добавлен метод post_form() для явного form-encoded POST
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Taxi135_TM_Exception extends Exception {
    public $api_code  = 0;
    public $api_descr = '';
    public $api_data  = null;

    public function __construct( $code, $descr, $data ) {
        parent::__construct( "TM API error {$code}: {$descr}", 0 );
        $this->api_code  = (int) $code;
        $this->api_descr = (string) $descr;
        $this->api_data  = $data;
    }
}

class Taxi135_TM_Client {

    const BASE_PATH = '/common_api/1.0';
    const TAPI_PATH = '/tm_tapi/1.0';

    /** @return array */
    public static function settings() {
        $opt = get_option( TAXI135_OPTION, [] );
        return wp_parse_args( $opt, [
            'host'         => '',
            'user_id'      => '',
            'secret'       => '',
            'allow_public' => 0,
        ] );
    }

    public static function is_configured() {
        $s = self::settings();
        return ! empty( $s['host'] ) && ! empty( $s['secret'] );
    }

    private static function build_query( array $params ) {
        $parts = [];
        foreach ( $params as $k => $v ) {
            if ( $v === null || $v === '' ) { continue; }
            if ( is_bool( $v ) ) { $v = $v ? 'true' : 'false'; }
            $parts[] = rawurlencode( $k ) . '=' . rawurlencode( (string) $v );
        }
        return implode( '&', $parts );
    }

    /** Обычный GET — user_id только в заголовке X-User-Id */
    public static function get( $endpoint, array $params = [] ) {
        $query = self::build_query( $params );
        return self::request( 'GET', self::BASE_PATH, $endpoint, $query, null );
    }

    /**
     * GET с user_id в query-строке.
     * Некоторые версии TaxiMaster требуют user_id как параметр запроса,
     * а не только в заголовке X-User-Id.
     */
    public static function get_with_uid( $endpoint, array $params = [] ) {
        $s = self::settings();
        if ( ! empty( $s['user_id'] ) ) {
            $params = array_merge( [ 'user_id' => $s['user_id'] ], $params );
        }
        $query = self::build_query( $params );
        return self::request( 'GET', self::BASE_PATH, $endpoint, $query, null );
    }

    public static function post( $endpoint, array $params = [], $json_body = false ) {
        if ( $json_body ) {
            $body  = wp_json_encode( $params );
            $query = '';
        } else {
            $body  = self::build_query( $params );
            $query = $body;
        }
        return self::request( 'POST', self::BASE_PATH, $endpoint, $query, $body, $json_body );
    }

    /**
     * POST с user_id в теле запроса.
     * Некоторые версии TaxiMaster требуют user_id как параметр тела.
     */
    public static function post_with_uid( $endpoint, array $params = [] ) {
        $s = self::settings();
        if ( ! empty( $s['user_id'] ) ) {
            $params = array_merge( [ 'user_id' => $s['user_id'] ], $params );
        }
        $body  = self::build_query( $params );
        return self::request( 'POST', self::BASE_PATH, $endpoint, $body, $body, false );
    }

    private static function request( $method, $api_path, $endpoint, $query, $body, $json_body = false ) {
        $s = self::settings();
        if ( empty( $s['host'] ) || empty( $s['secret'] ) ) {
            throw new RuntimeException( 'TMAPI не настроен. Откройте Настройки → Такси 135.' );
        }

        /* Подпись вычисляется из строки параметров (без самой подписи) + секрет */
        $signature = md5( $query . $s['secret'] );
        $path      = $api_path . '/' . ltrim( $endpoint, '/' );
        if ( $query !== '' && $method === 'GET' ) {
            $path .= '?' . $query;
        }
        $url = 'https://' . $s['host'] . $path;

        $headers = [
            'Signature: ' . $signature,
            'Accept: application/json',
        ];
        if ( ! empty( $s['user_id'] ) ) {
            $headers[] = 'X-User-Id: ' . $s['user_id'];
        }
        if ( $body !== null ) {
            $headers[] = $json_body
                ? 'Content-Type: application/json'
                : 'Content-Type: application/x-www-form-urlencoded';
        }

        if ( ! function_exists( 'curl_init' ) ) {
            throw new RuntimeException( 'PHP cURL расширение недоступно.' );
        }

        $ch = curl_init( $url );
        curl_setopt_array( $ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER         => false,
            CURLOPT_CUSTOMREQUEST  => $method,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => 0,
        ] );
        if ( $body !== null ) {
            curl_setopt( $ch, CURLOPT_POSTFIELDS, $body );
        }

        $resp = curl_exec( $ch );
        if ( $resp === false ) {
            $err = curl_error( $ch );
            curl_close( $ch );
            throw new RuntimeException( 'TMAPI недоступен: ' . $err );
        }
        $http = curl_getinfo( $ch, CURLINFO_HTTP_CODE );
        curl_close( $ch );

        $json = json_decode( $resp, true );
        if ( ! is_array( $json ) ) {
            throw new RuntimeException( 'TMAPI вернул не-JSON (HTTP ' . $http . '): ' . substr( (string) $resp, 0, 200 ) );
        }
        if ( ! isset( $json['code'] ) ) {
            throw new RuntimeException( 'TMAPI неожиданный ответ' );
        }
        if ( (int) $json['code'] !== 0 ) {
            throw new Taxi135_TM_Exception(
                $json['code'],
                isset( $json['descr'] ) ? $json['descr'] : '',
                isset( $json['data'] )  ? $json['data']  : null
            );
        }
        return isset( $json['data'] ) ? $json['data'] : null;
    }

    public static function tapi_get( $endpoint, array $params = [] ) {
        return self::tapi_request( 'GET', $endpoint, $params );
    }

    public static function tapi_post( $endpoint, array $params = [] ) {
        return self::tapi_request( 'POST', $endpoint, $params );
    }

    private static function tapi_request( $method, $endpoint, array $params ) {
        $s = self::settings();
        if ( empty( $s['host'] ) || empty( $s['secret'] ) ) {
            throw new RuntimeException( 'TMAPI не настроен.' );
        }

        $query     = self::build_query( $params );
        $signature = md5( $query . $s['secret'] );
        $params['signature'] = $signature;
        $full_query = self::build_query( $params );

        $path = self::TAPI_PATH . '/' . ltrim( $endpoint, '/' );
        if ( $method === 'GET' ) {
            $url  = 'https://' . $s['host'] . $path . '?' . $full_query;
            $body = null;
        } else {
            $url  = 'https://' . $s['host'] . $path;
            $body = $full_query;
        }

        $headers = [ 'Accept: application/xml' ];
        if ( $body !== null ) {
            $headers[] = 'Content-Type: application/x-www-form-urlencoded';
        }

        $ch = curl_init( $url );
        curl_setopt_array( $ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER         => false,
            CURLOPT_CUSTOMREQUEST  => $method,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => 0,
        ] );
        if ( $body !== null ) {
            curl_setopt( $ch, CURLOPT_POSTFIELDS, $body );
        }

        $resp = curl_exec( $ch );
        if ( $resp === false ) {
            $err = curl_error( $ch );
            curl_close( $ch );
            throw new RuntimeException( 'TAPI недоступен: ' . $err );
        }
        curl_close( $ch );

        libxml_use_internal_errors( true );
        $xml = simplexml_load_string( (string) $resp );
        if ( $xml === false ) {
            $json = json_decode( $resp, true );
            if ( is_array( $json ) && isset( $json['code'] ) ) {
                if ( (int) $json['code'] !== 0 ) {
                    throw new Taxi135_TM_Exception( $json['code'], $json['descr'] ?? '', $json['data'] ?? null );
                }
                return $json['data'] ?? null;
            }
            throw new RuntimeException( 'TAPI вернул не-XML: ' . substr( (string) $resp, 0, 200 ) );
        }

        $code  = (int) $xml->code;
        $descr = (string) $xml->descr;
        if ( $code !== 0 ) {
            $data_arr = self::xml_to_array( $xml->data );
            throw new Taxi135_TM_Exception( $code, $descr, $data_arr );
        }

        return isset( $xml->data ) ? self::xml_to_array( $xml->data ) : [];
    }

    private static function xml_to_array( $xml ) {
        if ( ! $xml instanceof SimpleXMLElement ) { return []; }
        $arr = [];
        foreach ( $xml->children() as $key => $child ) {
            $val = ( $child->count() > 0 ) ? self::xml_to_array( $child ) : (string) $child;
            if ( isset( $arr[ $key ] ) ) {
                if ( ! is_array( $arr[ $key ] ) || ! isset( $arr[ $key ][0] ) ) {
                    $arr[ $key ] = [ $arr[ $key ] ];
                }
                $arr[ $key ][] = $val;
            } else {
                $arr[ $key ] = $val;
            }
        }
        return $arr;
    }
}
