<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<div class="t135-app" id="t135-app">

    <!-- Mobile top bar -->
    <header class="t135-mobile-topbar">
        <button class="t135-hamburger" id="t135-hamburger" type="button" aria-label="Меню">
            <span></span><span></span><span></span>
        </button>
        <span class="t135-mobile-logo">135 Диспетчерская</span>
        <span id="t135-mobile-page-title" class="t135-mobile-page-title">Дашборд</span>
    </header>

    <!-- Sidebar overlay (mobile) -->
    <div class="t135-sidebar-overlay" id="t135-sidebar-overlay"></div>

    <aside class="t135-sidebar" id="t135-sidebar">
        <div class="t135-brand">
            <span class="t135-logo">135</span>
            <span class="t135-brand-text">Диспетчерская</span>
        </div>
        <nav class="t135-nav">
            <a href="javascript:void(0)" data-nav="dashboard"  class="t135-nav-item"><span class="t135-nav-icon">📊</span><span>Дашборд</span></a>
            <a href="javascript:void(0)" data-nav="orders"     class="t135-nav-item"><span class="t135-nav-icon">📋</span><span>Текущие заказы</span></a>
            <a href="javascript:void(0)" data-nav="finished"   class="t135-nav-item"><span class="t135-nav-icon">✅</span><span>Выполненные</span></a>
            <a href="javascript:void(0)" data-nav="new-order"  class="t135-nav-item"><span class="t135-nav-icon">➕</span><span>Создать заказ</span></a>
            <a href="javascript:void(0)" data-nav="reports"    class="t135-nav-item"><span class="t135-nav-icon">📈</span><span>Отчёты</span></a>

            <a href="javascript:void(0)" data-nav="crews"      class="t135-nav-item"><span class="t135-nav-icon">🚗</span><span>Экипажи</span></a>
            <a href="javascript:void(0)" data-nav="map"        class="t135-nav-item"><span class="t135-nav-icon">🗺</span><span>Карта</span></a>
            <a href="javascript:void(0)" data-nav="drivers"    class="t135-nav-item"><span class="t135-nav-icon">👤</span><span>Водители</span></a>
            <a href="javascript:void(0)" data-nav="ratings"    class="t135-nav-item"><span class="t135-nav-icon">⭐</span><span>Рейтинги</span></a>
        </nav>
        <div class="t135-status">
            <span class="t135-dot"></span>
            <span id="t135-live-label">Live</span>
        </div>
    </aside>

    <main class="t135-main">
        <header class="t135-topbar">
            <h2 id="t135-page-title">Дашборд</h2>
            <div class="t135-topbar-actions">
                <span id="t135-error-banner" class="t135-error-banner" style="display:none;"></span>
                <button type="button" class="t135-btn t135-btn-ghost" id="t135-refresh" title="Обновить">↻ Обновить</button>
            </div>
        </header>
        <section class="t135-content">
            <!-- ИСПРАВЛЕНО: страницы скрыты через CSS-класс, не через атрибут hidden -->
            <div id="t135-page-dashboard"   class="t135-page"></div>
            <div id="t135-page-orders"      class="t135-page t135-page-hidden"></div>
            <div id="t135-page-finished"    class="t135-page t135-page-hidden"></div>
            <div id="t135-page-new-order"   class="t135-page t135-page-hidden"></div>
            <div id="t135-page-reports"     class="t135-page t135-page-hidden"></div>

            <div id="t135-page-crews"       class="t135-page t135-page-hidden"></div>
            <div id="t135-page-map"         class="t135-page t135-page-hidden"></div>
            <div id="t135-page-drivers"     class="t135-page t135-page-hidden"></div>
            <div id="t135-page-ratings"     class="t135-page t135-page-hidden"></div>
        </section>
    </main>

    <!-- Mobile bottom navigation -->
    <nav class="t135-bottom-nav" aria-label="Мобильная навигация">
        <a href="javascript:void(0)" data-nav="dashboard" class="t135-bnav-item">
            <span class="t135-bnav-icon">📊</span><span>Дашборд</span>
        </a>
        <a href="javascript:void(0)" data-nav="orders" class="t135-bnav-item">
            <span class="t135-bnav-icon">📋</span><span>Заказы</span>
        </a>
        <a href="javascript:void(0)" data-nav="new-order" class="t135-bnav-item">
            <span class="t135-bnav-icon">➕</span><span>Создать</span>
        </a>
        <a href="javascript:void(0)" data-nav="ratings" class="t135-bnav-item">
            <span class="t135-bnav-icon">⭐</span><span>Рейтинг</span>
        </a>
        <a href="javascript:void(0)" data-nav="drivers" class="t135-bnav-item">
            <span class="t135-bnav-icon">👤</span><span>Водители</span>
        </a>
        <a href="javascript:void(0)" data-nav="map" class="t135-bnav-item">
            <span class="t135-bnav-icon">🗺</span><span>Карта</span>
        </a>
    </nav>

    <div class="t135-toast" id="t135-toast" style="display:none;"></div>
</div>
