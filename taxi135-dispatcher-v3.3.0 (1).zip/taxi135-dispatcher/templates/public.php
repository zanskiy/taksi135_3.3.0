<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<div class="t135pub-wrap" id="t135pub-wrap">
    <div id="t135pub-map" style="width:100%;height:<?php echo esc_attr($height); ?>;border-radius:10px;overflow:hidden;"></div>

    <div class="t135pub-panel" id="t135pub-panel">
        <button class="t135pub-order-btn" id="t135pub-open-order" type="button">
            &#x1F696; <?php echo esc_html( $opt['public_order_title'] ); ?>
        </button>
        <?php if ( ! empty( $opt['viber_dispatcher'] ) ) : ?>
        <a class="t135pub-viber-btn" href="<?php echo esc_url( $opt['viber_dispatcher'] ); ?>" target="_blank" rel="noopener noreferrer">
            &#x1F4AC; Написать диспетчеру
        </a>
        <?php endif; ?>
        <?php if ( ! empty( $opt['director_contact'] ) ) : ?>
        <a class="t135pub-director-btn" href="<?php echo esc_url( $opt['director_contact'] ); ?>" target="_blank" rel="noopener noreferrer">
            &#x1F4DE; Связаться с директором
        </a>
        <?php endif; ?>
    </div>

    <div class="t135pub-modal" id="t135pub-modal" hidden>
        <div class="t135pub-modal-box">
            <div class="t135pub-modal-head">
                <h3>&#x1F696; Вызвать такси</h3>
                <button type="button" class="t135pub-close" id="t135pub-close" aria-label="Закрыть">&times;</button>
            </div>
            <div id="t135pub-result" class="t135pub-result" hidden></div>
            <form id="t135pub-form" autocomplete="on" novalidate>
                <div class="t135pub-field">
                    <label for="t135pub-phone">Ваш телефон <span class="t135pub-req">*</span></label>
                    <input type="tel" id="t135pub-phone" name="phone" placeholder="+375 (XX) XXX-XX-XX" required autocomplete="tel">
                </div>
                <div class="t135pub-field">
                    <label for="t135pub-source">Адрес подачи <span class="t135pub-req">*</span></label>
                    <input type="text" id="t135pub-source" name="source" placeholder="ул. Ленина, 1" required autocomplete="street-address">
                </div>
                <div class="t135pub-field">
                    <label for="t135pub-dest">Куда едем</label>
                    <input type="text" id="t135pub-dest" name="destination" placeholder="Необязательно" autocomplete="off">
                </div>
                <div class="t135pub-field">
                    <label for="t135pub-name">Ваше имя</label>
                    <input type="text" id="t135pub-name" name="customer" placeholder="Необязательно" autocomplete="name">
                </div>
                <div class="t135pub-field">
                    <label for="t135pub-comment">Комментарий</label>
                    <textarea id="t135pub-comment" name="comment" rows="2" placeholder="Пожелания к заказу"></textarea>
                </div>
                <button type="submit" class="t135pub-submit" id="t135pub-submit">Заказать такси</button>
            </form>
        </div>
    </div>
</div>
