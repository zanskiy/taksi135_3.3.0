<?php
/**
 * Plugin Name: Такси 135 — Диспетчерская
 * Plugin URI:  https://taxi135.by/
 * Description: Диспетчерская панель TaxiMaster: текущие и выполненные заказы, отчёты по водителям и прибыли, сообщения водителям через TMDriver, рейтинги, карта экипажей, пополнение баланса.
 * Version:     3.3.0
 * Author:      Такси 135
 * Text Domain: taxi135-dispatcher
 * Domain Path: /languages
 * Requires PHP: 7.4
 * Requires at least: 5.8
 * License:     GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'TAXI135_PLUGIN_FILE', __FILE__ );
define( 'TAXI135_PLUGIN_DIR',  plugin_dir_path( __FILE__ ) );
define( 'TAXI135_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );
define( 'TAXI135_VERSION',     '3.3.0' );
define( 'TAXI135_REST_NS',     'taxi135/v1' );
define( 'TAXI135_OPTION',      'taxi135_settings' );

require_once TAXI135_PLUGIN_DIR . 'includes/class-tm-client.php';
require_once TAXI135_PLUGIN_DIR . 'includes/class-rest.php';
require_once TAXI135_PLUGIN_DIR . 'includes/class-admin.php';
require_once TAXI135_PLUGIN_DIR . 'includes/class-shortcode.php';

register_activation_hook( __FILE__, function () {
    if ( false === get_option( TAXI135_OPTION ) ) {
        add_option( TAXI135_OPTION, [
            'host'               => '',
            'user_id'            => '',
            'secret'             => '',
            'allow_public'       => 0,
            'viber_dispatcher'   => '',
            'director_contact'   => '',
            'public_order_title' => 'Вызвать такси',
            'public_map_zoom'    => 13,
            'public_map_lat'     => 53.9,
            'public_map_lng'     => 27.5667,
        ] );
    }
} );

add_action( 'plugins_loaded', function () {
    load_plugin_textdomain( 'taxi135-dispatcher', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
    Taxi135_Admin::init();
    Taxi135_REST::init();
    Taxi135_Shortcode::init();
    Taxi135_Public_Shortcode::init();
} );
